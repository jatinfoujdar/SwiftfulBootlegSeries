# EscribiVille 📚
<p align="leading">MACC Monterrey 2023</p>
<img width="1920" height="1080" alt="5" src="https://github.com/user-attachments/assets/ddd78139-6386-4384-8491-be9bf7e4133a" />


## 📝 What is EscribiVille?

<p align="leading">Escribiville is an educational app designed for children ages 5 to 8, bringing reading, writing, and basic math to life through interactive and fun activities, where they focus at:

- **Reading 🚀** <br>
Children dive into exciting stories, word-building games, and playful challenges alongside friendly forest animals, making every step of reading an adventure.

- **Writing ✏️** <br>
From tracing letters to forming words and sentences, kids strengthen their writing skills with interactive exercises that make learning to write easy, creative, and enjoyable.

- **Basic Math 📚**<br>
Through fun games and challenges, children explore the world of numbers and master addition, subtraction, multiplication, and division in a way that feels like play, not homework.

With Escribiville, learning becomes a magical journey where kids build the essential foundations of education while having fun! 🧩</p>

> 𝗘𝘀𝗰𝗿𝗶𝗯𝗶𝘃𝗶𝗹𝗹𝗲 was born as part of the 𝗠𝗔𝗖𝗖 𝟮𝟬𝟮𝟯 in Monterrey, where we embraced the challenge of "Education for everybody." 🌍📚
With this app, we aim to bring quality education to children aged 5 to 8 through three key pillars: reading, writing, and basic math, all designed with fun and interactive activities. Our goal is to inspire kids to discover that learning can be an exciting and accessible experience for everyone. 💡


## Features 🧑‍💻
<div align="center">
    <img style="width:8%; height:7%" src="https://github.com/clxsrdev/ManglarExplora/assets/99055585/705f8dd3-c529-4c3b-9471-5f4f366a0ca7" />
    <img style="width:8%; height:7%" src="https://github.com/clxsrdev/ManglarExplora/assets/99055585/ee94ac9b-83ff-4a7a-947b-102968dd2954" />
</div><br>

- **SwiftUI:** for the creation of interfaces, data flow, animations, window navigation, and other factors <br>
- **Adobe Ilustrator:** used to create all the visual elements found within the application, with the purpose of maintaining a consistent theme throughout (doing all by myself)

## App previews 📱
<img width="1920" height="1080" alt="6" src="https://github.com/user-attachments/assets/1ce2783e-8c42-4ca3-b2a0-56989fd4d305" />
<img width="1920" height="1080" alt="7" src="https://github.com/user-attachments/assets/d5392f36-1293-410b-b1ef-f600dd7ec0ac" />



