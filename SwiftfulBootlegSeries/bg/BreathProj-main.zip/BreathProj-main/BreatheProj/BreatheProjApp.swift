//
//  BreatheProjApp.swift
//  BreatheProj
//
//  Created by Tymofii Bezverkhyi on 21.01.2025.
//

import SwiftUI

@main
struct BreatheProjApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
