//
//  Created by Timothy Moose on 1/27/24.
//

import Foundation

public typealias MaterialTabsHeaderContext = HeaderContext
