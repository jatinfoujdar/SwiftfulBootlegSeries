//
//  StickyHeaderScrollContext.swift
//  SwiftUIMaterialTabs
//
//  Created by Timothy Moose on 2/16/24.
//

import Foundation

public typealias StickyHeaderScrollContext = MaterialTabsScrollContext<NoTab>
