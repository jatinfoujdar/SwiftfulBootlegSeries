# crAion's Animated SwiftUI Onboarding

This is an onboarding I did for my little app to analyze childs drawings with AI: [crAion](https://apps.apple.com/app/id6473756867).

I'm open sourcing it since it went pretty [viral on Twitter](https://x.com/juanjovn/status/1805194292606255314) 😝

If you like content like this, I made a full iOS template to launch iOS apps fast here: **[WrapFast](https://WrapFa.st?ref=craion_onboarding)** 🌯⚡️

📹 Watch a demo on video 👇

[![Watch the video](https://img.youtube.com/vi/ZVfuvWMj3fU/maxresdefault.jpg)](https://www.youtube.com/watch?v=ZVfuvWMj3fU)
