import SwiftUI

@main
struct crAion_OnboardingApp: App {
    var body: some Scene {
        WindowGroup {
            OnboardingView()
        }
    }
}
