import Foundation

struct Level: Identifiable {
    let id: Int
    let prompt: String
    let answer: String
    let category: LevelCategory
    
    var scrambledLetters: [Letter] {
        // Simple consistent scrambling for now, or just random
        let characters = Array(answer)
        return characters.map { Letter(character: String($0)) }.shuffled()
    }
}

enum LevelCategory: String {
    case classic = "Classic"
    case riddle = "Riddle"
    case emoji = "Emoji"
    case fun = "Fun"
}

struct Letter: Identifiable, Equatable, Hashable {
    let id = UUID()
    let character: String
}
