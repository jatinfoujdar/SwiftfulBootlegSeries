import Foundation

struct LevelData {
    static let classic: [Level] = [
        Level(id: 1, prompt: "Guess the Color", answer: "GREEN", category: .classic),
        Level(id: 2, prompt: "A Fruit", answer: "APPLE", category: .classic),
        Level(id: 3, prompt: "Solar System Star", answer: "SUN", category: .classic),
        Level(id: 4, prompt: "Opposite of Night", answer: "DAY", category: .classic),
        Level(id: 5, prompt: "A Pet", answer: "CAT", category: .classic),
        Level(id: 6, prompt: "Large Body of Water", answer: "OCEAN", category: .classic),
        Level(id: 7, prompt: "Guess the Color", answer: "BLUE", category: .classic),
        Level(id: 8, prompt: "A Season", answer: "WINTER", category: .classic),
        Level(id: 9, prompt: "Vehicle", answer: "CAR", category: .classic),
        Level(id: 10, prompt: "Planet", answer: "MARS", category: .classic)
    ]
    
    static let riddle: [Level] = [
        Level(id: 1, prompt: "I have keys but no locks.", answer: "PIANO", category: .riddle),
        Level(id: 2, prompt: "I have cities but no houses.", answer: "MAP", category: .riddle),
        Level(id: 3, prompt: "What has to be broken before you can use it?", answer: "EGG", category: .riddle),
        Level(id: 4, prompt: "I’m tall when I’m young, and I’m short when I’m old.", answer: "CANDLE", category: .riddle),
        Level(id: 5, prompt: "What month of the year has 28 days?", answer: "ALL", category: .riddle),
        Level(id: 6, prompt: "What is full of holes but still holds water?", answer: "SPONGE", category: .riddle),
        Level(id: 7, prompt: "What is always in front of you but can’t be seen?", answer: "FUTURE", category: .riddle),
        Level(id: 8, prompt: "There’s a one-story house in which everything is yellow. Yellow walls, yellow doors, yellow furniture. What color are the stairs?", answer: "NONE", category: .riddle),
        Level(id: 9, prompt: "What can you break, even if you never pick it up or touch it?", answer: "PROMISE", category: .riddle),
        Level(id: 10, prompt: "What goes up but never comes down?", answer: "AGE", category: .riddle)
    ]
    
    static let emoji: [Level] = [
        Level(id: 1, prompt: "👻🏠", answer: "HAUNTED", category: .emoji),
        Level(id: 2, prompt: "🌧️🏹", answer: "RAINBOW", category: .emoji),
        Level(id: 3, prompt: "🔥🚒", answer: "FIRETRUCK", category: .emoji),
        Level(id: 4, prompt: "🕶️☀️", answer: "SUNGLASSES", category: .emoji),
        Level(id: 5, prompt: "🧊🍦", answer: "ICECREAM", category: .emoji),
        Level(id: 6, prompt: "🛌😴", answer: "SLEEP", category: .emoji),
        Level(id: 7, prompt: "👑🦁", answer: "LIONKING", category: .emoji),
        Level(id: 8, prompt: "🚀🌕", answer: "MOON", category: .emoji),
        Level(id: 9, prompt: "🌻☀️", answer: "SUNFLOWER", category: .emoji),
        Level(id: 10, prompt: "🕷️🕸️", answer: "SPIDERMAN", category: .emoji)
    ]
    
    static let fun: [Level] = [
        Level(id: 1, prompt: "A wizard's stick", answer: "WAND", category: .fun),
        Level(id: 2, prompt: "Vampire's fear", answer: "GARLIC", category: .fun),
        Level(id: 3, prompt: "Pirate's favorite letter", answer: "R", category: .fun),
        Level(id: 4, prompt: "A funny person", answer: "CLOWN", category: .fun),
        Level(id: 5, prompt: "Santa's ride", answer: "SLEIGH", category: .fun),
        Level(id: 6, prompt: "A spooky ghost says", answer: "BOO", category: .fun),
        Level(id: 7, prompt: "A dancing snack", answer: "POPCORN", category: .fun),
        Level(id: 8, prompt: "Superhero wear", answer: "CAPE", category: .fun),
        Level(id: 9, prompt: "Zombie food", answer: "BRAINS", category: .fun),
        Level(id: 10, prompt: "A magical pony", answer: "UNICORN", category: .fun)
    ]
    
    static func getLevels(for category: LevelCategory) -> [Level] {
        switch category {
        case .classic: return classic
        case .riddle: return riddle
        case .emoji: return emoji
        case .fun: return fun
        }
    }
}
