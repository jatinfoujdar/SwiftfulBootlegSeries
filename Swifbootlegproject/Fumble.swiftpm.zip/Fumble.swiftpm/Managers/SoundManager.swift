import Foundation
import AVFoundation
import UIKit


@MainActor
class SoundManager {
    static let shared = SoundManager()
    
    // System sound IDs
    private let tapSoundID: SystemSoundID = 1057    // For home icon / general tap
    private let selectSoundID: SystemSoundID = 1105 // For category select
    private let backSoundID: SystemSoundID = 1052   // For back button
    private let dragStartSoundID: SystemSoundID = 1123
    private let dragEndSoundID: SystemSoundID = 1124
    private let swapSoundID: SystemSoundID = 1103
    private let moveSoundID: SystemSoundID = 1104
    private let logoSoundID: SystemSoundID = 1101
    
    // AVAudioPlayers for custom sounds
    private var teddyPlayer: AVAudioPlayer?
    private var levelUpPlayer: AVAudioPlayer?
    private var successPlayer: AVAudioPlayer?
    
    // Persistent Generators for performance
    private let impactGenerator = UIImpactFeedbackGenerator(style: .light)
    private let notificationGenerator = UINotificationFeedbackGenerator()
    
    private init() {
        setupAudioPlayers()
        // Pre-warm haptics
        impactGenerator.prepare()
        notificationGenerator.prepare()
    }
    
    private func setupAudioPlayers() {
        // Configure AVAudioSession for low latency
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to set audio session category: \(error)")
        }

        if let url = Bundle.main.url(forResource: "teddy", withExtension: "mp3") {
            teddyPlayer = try? AVAudioPlayer(contentsOf: url)
            teddyPlayer?.prepareToPlay()
            print("✅ Teddy sound loaded")
        } else {
            print("❌ Teddy sound NOT found in bundle")
        }
        
        if let url = Bundle.main.url(forResource: "level-up", withExtension: "mp3") {
            levelUpPlayer = try? AVAudioPlayer(contentsOf: url)
            levelUpPlayer?.prepareToPlay()
             print("✅ Level-up sound loaded")
        } else {
             print("❌ Level-up sound NOT found in bundle")
        }
        
        if let url = Bundle.main.url(forResource: "great-success", withExtension: "mp3") {
            successPlayer = try? AVAudioPlayer(contentsOf: url)
            successPlayer?.prepareToPlay()
             print("✅ Success sound loaded")
        } else {
             print("❌ Success sound NOT found in bundle")
        }
    }
    
    func playTeddySound() {
        // Stop and reset to allow rapid replay during staggering
        teddyPlayer?.stop()
        teddyPlayer?.currentTime = 0
        teddyPlayer?.play()
    }
    
    func playLogoTapSound() {
        AudioServicesPlaySystemSound(logoSoundID)
    }
    
    func playHomeTapSound() {
        AudioServicesPlaySystemSound(tapSoundID)
    }
    
    func playMenuSelectSound() {
        AudioServicesPlaySystemSound(selectSoundID)
    }
    
    func playBackSound() {
        AudioServicesPlaySystemSound(backSoundID)
    }
    
    func playDragStartSound() {
        AudioServicesPlaySystemSound(dragStartSoundID)
    }
    
    func playDragEndSound() {
        AudioServicesPlaySystemSound(dragEndSoundID)
    }
    
    func playSwapSound() {
        AudioServicesPlaySystemSound(swapSoundID)
        impactGenerator.impactOccurred()
    }
    
    func playMoveSound() {
        AudioServicesPlaySystemSound(moveSoundID)
    }
    
    func playWinSound() {
        // Haptic feedback for win
        notificationGenerator.notificationOccurred(.success)
        
        // Use the great-success sound for level completion
        playGreatSuccessSound()
    }
    
    func playLevelUpSound() {
        levelUpPlayer?.stop()
        levelUpPlayer?.currentTime = 0
        levelUpPlayer?.play()
    }
    
    func playGreatSuccessSound() {
        successPlayer?.stop()
        successPlayer?.currentTime = 0
        successPlayer?.play()
    }
}
