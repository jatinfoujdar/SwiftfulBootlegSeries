import CoreMotion
import SwiftUI
import Combine

@MainActor
class MotionManager: ObservableObject {
    private let motionManager = CMMotionManager()
    @Published var x: Double = 0.0
    @Published var y: Double = 0.0
    
    var onShake: (@MainActor () -> Void)?
    
    init() {
        startAccelerometers()
    }
    
    func startAccelerometers() {
        if motionManager.isAccelerometerAvailable {
            motionManager.accelerometerUpdateInterval = 1/60.0
            motionManager.startAccelerometerUpdates(to: .main) { [weak self] data, error in
                guard let data = data else { return }
                
                // Detect Shake
                let acceleration = data.acceleration
                let magnitude = sqrt(pow(acceleration.x, 2) + pow(acceleration.y, 2) + pow(acceleration.z, 2))
                
                if magnitude > 2.5 { // Threshold for shake
                    self?.onShake?()
                }
                
                withAnimation(.linear(duration: 0.1)) {
                    self?.x = data.acceleration.x
                    self?.y = data.acceleration.y
                }
            }
        }
    }
    
    func stopAccelerometers() {
        motionManager.stopAccelerometerUpdates()
    }
}
