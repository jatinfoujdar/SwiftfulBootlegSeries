import SwiftUI



struct ContentView: View {
    @AppStorage("hasSeenIntro") private var hasSeenIntro = false
    
    var body: some View {
        if hasSeenIntro {
            HomeView()
                .transition(.opacity)
        } else {
            IntroView(hasSeenIntro: $hasSeenIntro)
                .transition(.opacity)
        }
    }
}



#Preview {
    ContentView()
}
