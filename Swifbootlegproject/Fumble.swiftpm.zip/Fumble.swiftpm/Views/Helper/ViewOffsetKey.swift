import SwiftUI

struct ViewOffsetKey: PreferenceKey {
    typealias Value = [UUID: CGPoint]
    static var defaultValue: [UUID: CGPoint] { [:] }
    
    static func reduce(value: inout [UUID : CGPoint], nextValue: () -> [UUID : CGPoint]) {
        value.merge(nextValue()) { $1 }
    }
}
