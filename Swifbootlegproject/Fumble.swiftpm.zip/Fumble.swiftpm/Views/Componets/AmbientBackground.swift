import SwiftUI

struct AmbientBackground: View {
    var motionX: Double = 0
    var motionY: Double = 0
    @State private var animate = false
    
    
    let colors: [Color] = [
        Color(hex: "4A00E0"), // Deep Purple
        Color(hex: "8E2DE2"), // Violet
        Color(hex: "00C6FF"), // Cyan
        Color(hex: "0072FF"), // Blue
        Color(hex: "FF0099"), // Pinkish
        Color(hex: "493240")  // Darker tone
    ]
    
    var body: some View {
        ZStack {
            
            Color(hex: "0f0c29").ignoresSafeArea()
            
            GeometryReader { geo in
                let w = geo.size.width
                let h = geo.size.height
                
                ZStack {
                    
                    Circle()
                        .fill(colors[0])
                        .frame(width: w * 0.8, height: w * 0.8)
                        .blur(radius: 80)
                        .offset(x: (animate ? -w * 0.2 : w * 0.1) + CGFloat(motionX) * 30, 
                                y: (animate ? -h * 0.2 : -h * 0.1) + CGFloat(motionY) * 30)
                        .animation(.easeInOut(duration: 6).repeatForever(autoreverses: true), value: animate)
                    
                    
                    Circle()
                        .fill(colors[2])
                        .frame(width: w * 0.8, height: w * 0.8)
                        .blur(radius: 80)
                        .offset(x: (animate ? w * 0.2 : -w * 0.1) - CGFloat(motionX) * 20, 
                                y: (animate ? h * 0.2 : h * 0.1) - CGFloat(motionY) * 20)
                        .animation(.easeInOut(duration: 7).repeatForever(autoreverses: true), value: animate)
                    
                    
                    Circle()
                        .fill(colors[4])
                        .frame(width: w * 0.6, height: w * 0.6)
                        .blur(radius: 90)
                        .offset(x: (animate ? -w * 0.3 : w * 0.3) + CGFloat(motionX) * 40, 
                                y: (animate ? h * 0.1 : -h * 0.1) + CGFloat(motionY) * 40)
                        .opacity(0.7)
                        .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: animate)
                    
                    
                    Circle()
                        .fill(colors[3])
                        .frame(width: w * 0.7, height: w * 0.7)
                        .blur(radius: 70)
                        .offset(x: (animate ? w * 0.3 : 0) - CGFloat(motionX) * 15, 
                                y: (animate ? -h * 0.3 : -h * 0.2) - CGFloat(motionY) * 15)
                        .opacity(0.6)
                        .animation(.easeInOut(duration: 5).repeatForever(autoreverses: true), value: animate)
                    
                  
                    Circle()
                        .fill(colors[5])
                        .frame(width: w * 0.9, height: w * 0.9)
                        .blur(radius: 100)
                        .offset(x: (animate ? -w * 0.4 : -w * 0.2) + CGFloat(motionX) * 10, 
                                y: (animate ? h * 0.3 : h * 0.4) + CGFloat(motionY) * 10)
                        .animation(.easeInOut(duration: 10).repeatForever(autoreverses: true), value: animate)
                }
            }
            .background(Color.black.opacity(0.2))
        }
        .ignoresSafeArea()
        .onAppear {
            animate = true
        }
    }
}


