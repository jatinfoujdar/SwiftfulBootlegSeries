import SwiftUI

struct DynamicLiquidBackground: View {
    let letterPositions: [UUID: CGPoint]
    let letters: [Letter]
    var baseSize: CGFloat = 80 // Default size matching LetterTile
    
    var body: some View {
        Canvas { context, size in
            let circleRadius: CGFloat = baseSize * 0.7 // Scale radius relative to letter size
            
            
            context.addFilter(.alphaThreshold(min: 0.5, color: .black.opacity(0.6)))
            context.addFilter(.blur(radius: 15))
            
            context.drawLayer { ctx in
                var points: [CGPoint] = []
                
                
                for letter in letters {
                    if let pos = letterPositions[letter.id] {
                        points.append(pos)
                    }
                }
                
                for point in points {
                    let rect = CGRect(x: point.x - circleRadius, y: point.y - circleRadius, width: circleRadius * 2, height: circleRadius * 2)
                    ctx.fill(Hexagon().path(in: rect), with: .color(.black.opacity(0.7)))
                }
                
                
                for i in 0..<points.count {
                    for j in i+1..<points.count {
                        let p1 = points[i]
                        let p2 = points[j]
                        let dist = hypot(p2.x - p1.x, p2.y - p1.y)
                        
                        let maxDist = circleRadius * 3.5
                        if dist < maxDist {
                            let bridgeWidth = circleRadius * 1.2 * (1.0 - (dist / maxDist))
                            
                            if bridgeWidth > 2 {
                                var path = Path()
                                let angle = atan2(p2.y - p1.y, p2.x - p1.x)
                                let perpAngle = angle + .pi / 2
                                
                                let p1a = CGPoint(x: p1.x + cos(perpAngle) * bridgeWidth, y: p1.y + sin(perpAngle) * bridgeWidth)
                                let p1b = CGPoint(x: p1.x - cos(perpAngle) * bridgeWidth, y: p1.y - sin(perpAngle) * bridgeWidth)
                                let p2a = CGPoint(x: p2.x + cos(perpAngle) * bridgeWidth, y: p2.y + sin(perpAngle) * bridgeWidth)
                                let p2b = CGPoint(x: p2.x - cos(perpAngle) * bridgeWidth, y: p2.y - sin(perpAngle) * bridgeWidth)
                                
                                let mid = CGPoint(x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2)
                                
                                path.move(to: p1a)
                                path.addQuadCurve(to: p2a, control: mid)
                                path.addLine(to: p2b)
                                path.addQuadCurve(to: p1b, control: mid)
                                path.closeSubpath()
                                
                                ctx.fill(path, with: .color(.black.opacity(0.7)))
                            }
                        }
                    }
                }
            }
        }
    }
}
