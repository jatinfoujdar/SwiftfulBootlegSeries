import SwiftUI

struct WaveBackgroundShape: Shape {
    let letterCount: Int
    let circleSize: CGFloat = 60
    let spacing: CGFloat = 10
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        guard letterCount > 0 else { return path }
        
        let totalWidth = rect.width
        let circleRadius = rect.height / 2
        
       
        
        let step = totalWidth / CGFloat(letterCount)
        
        for i in 0..<letterCount {
            let center = CGPoint(x: step * CGFloat(i) + step / 2, y: rect.height / 2)
            path.addEllipse(in: CGRect(x: center.x - circleRadius, y: center.y - circleRadius, width: circleRadius * 2, height: circleRadius * 2))
        }
        
        
        
        return path
    }
}


struct LiquidBlobView: View {
    let letterCount: Int
    var color: Color = .black.opacity(0.8)
    
    var body: some View {
        Canvas { context, size in
            let circleSize = size.height
            let step = size.width / CGFloat(letterCount)
            
            context.addFilter(.alphaThreshold(min: 0.5, color: color))
            context.addFilter(.blur(radius: 10))
            
            context.drawLayer { ctx in
                for i in 0..<letterCount {
                    let center = CGPoint(x: step * CGFloat(i) + step / 2, y: size.height / 2)
                    let rect = CGRect(x: center.x - circleSize/2, y: center.y - circleSize/2, width: circleSize, height: circleSize)
                    ctx.fill(Circle().path(in: rect), with: .color(color))
                    
                    
                    if i < letterCount - 1 {
                        let nextCenter = CGPoint(x: step * CGFloat(i+1) + step / 2, y: size.height / 2)
                        let midRect = CGRect(x: center.x, y: center.y - circleSize/2 + 10, width: nextCenter.x - center.x, height: circleSize - 20)
                         ctx.fill(Rectangle().path(in: midRect), with: .color(color))
                    }
                }
            }
        }
    }
}
