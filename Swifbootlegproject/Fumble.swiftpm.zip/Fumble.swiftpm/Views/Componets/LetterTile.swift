import SwiftUI

struct LetterTile: View {
    let letter: Letter
    var size: CGFloat = 80
    var fontSize: CGFloat = 50
    
    var body: some View {
        Text(letter.character)
            .font(.system(size: fontSize, weight: .heavy, design: .rounded))
            .foregroundColor(.white)
            .frame(width: size, height: size)
            .contentShape(Rectangle()) // Make the whole area hittable
            .accessibilityLabel("Letter \(letter.character)")
            .accessibilityAddTraits(.isButton)
            .accessibilityHint("Drag to reorder")
    }
}
