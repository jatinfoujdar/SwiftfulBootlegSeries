import SwiftUI

struct Hexagon: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        let x = rect.origin.x
        let y = rect.origin.y
        
        let hypotenuse = min(width, height) / 2
        let center = CGPoint(x: x + width / 2, y: y + height / 2)
        
        for i in 0..<6 {
            let angle = CGFloat(i) * .pi / 3 - .pi / 2
            let point = CGPoint(
                x: center.x + hypotenuse * cos(angle),
                y: center.y + hypotenuse * sin(angle)
            )
            
            if i == 0 {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }
        }
        
        path.closeSubpath()
        return path
    }
}
