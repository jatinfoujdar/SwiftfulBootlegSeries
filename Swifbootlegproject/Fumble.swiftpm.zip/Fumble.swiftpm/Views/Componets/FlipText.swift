import SwiftUI

struct FlipText: View {
    let text: String
    @State private var flip = false
    
    var body: some View {
        GeometryReader { geometry in
            let availableWidth = geometry.size.width
       
            let calculatedSize = min(80, (availableWidth * 0.9) / CGFloat(text.count))
            
            HStack(spacing: calculatedSize * 0.05) {
                ForEach(Array(text.enumerated()), id: \.offset) { index, char in
                    Text(String(char))
                        .font(.system(size: calculatedSize, weight: .black, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.3), radius: calculatedSize * 0.06, x: 0, y: calculatedSize * 0.06)
                        .rotation3DEffect(
                            .degrees(flip ? 0 : -120),
                            axis: (x: 1, y: 0.2, z: 0)
                        )
                        .opacity(flip ? 1 : 0)
                        .scaleEffect(flip ? 1.0 : 0.5)
                        .animation(
                            .spring(response: 0.5, dampingFraction: 0.6, blendDuration: 0)
                            .delay(Double(index) * 0.15),
                            value: flip
                        )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(height: 100)
        .onTapGesture {
            SoundManager.shared.playLogoTapSound()
            triggerAnimation()
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                triggerAnimation()
            }
        }
    }
    
    private func triggerAnimation() {
        flip = false
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
            flip = true
            playFlipSounds()
        }
    }
    
    private func playFlipSounds() {
        for index in 0..<text.count {
         
            let delay = Double(index) * 0.15
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                SoundManager.shared.playTeddySound()
            }
        }
    }
}

struct FlipText_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.black
            FlipText(text: "Jumblify")
        }
    }
}
