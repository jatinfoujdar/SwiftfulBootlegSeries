import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                let screenWidth = geometry.size.width

                
                ZStack {
                // Background
                AmbientBackground()
                    .overlay(Color.black.opacity(0.3)) // Slight overlay for consistency
                
                HStack(spacing: 0) {
                    // Left side: Title
                    VStack {
                        Spacer()
                        FlipText(text: "Jumbly")
                        Spacer()
                    }
                    .frame(width: screenWidth * 0.4)
                    
                    // Right side: Buttons
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(spacing: 20) {
                            Spacer(minLength: 10)
                            
                            NavigationLink(destination: LevelView(category: .classic)) {
                                MenuButton(title: "CLASSIC", icon: "gamecontroller.fill", index: 0, screenWidth: screenWidth * 0.5)
                            }
                            .simultaneousGesture(TapGesture().onEnded {
                                SoundManager.shared.playMenuSelectSound()
                            })
                            
                            NavigationLink(destination: LevelView(category: .riddle)) {
                                MenuButton(title: "RIDDLE", icon: "questionmark.circle.fill", index: 1, screenWidth: screenWidth * 0.5)
                            }
                            .simultaneousGesture(TapGesture().onEnded {
                                SoundManager.shared.playMenuSelectSound()
                            })
                            
                            NavigationLink(destination: LevelView(category: .emoji)) {
                                MenuButton(title: "EMOJI", icon: "face.smiling.fill", index: 2, screenWidth: screenWidth * 0.5)
                            }
                            .simultaneousGesture(TapGesture().onEnded {
                                SoundManager.shared.playMenuSelectSound()
                            })
                            
                            NavigationLink(destination: LevelView(category: .fun)) {
                                MenuButton(title: "FUN", icon: "theatermasks.fill", index: 3, screenWidth: screenWidth * 0.5)
                            }
                            .simultaneousGesture(TapGesture().onEnded {
                                SoundManager.shared.playMenuSelectSound()
                            })
                            
                            Spacer(minLength: 20)
                        }
                        .frame(minHeight: geometry.size.height)
                    }
                    .frame(width: screenWidth * 0.6)
                }
            }
        }
        }
        .navigationViewStyle(.stack)
    }
    
    struct MenuButton: View {
        let title: String
        let icon: String
        let index: Int
        let screenWidth: CGFloat
        
        @State private var isAnimating = false
        
        var body: some View {
            HStack(spacing: 20) {
                
                ZStack {
                    if icon.count == 1 {
                        Text(icon)
                            .font(.system(size: 40))
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 30))
                    }
                }
                .frame(width: 50, height: 50)
                                            

                
                Text(title)
                    .font(.system(.title3, design: .rounded))
                    .fontWeight(.bold)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                
                Spacer(minLength: 0)
            }
            .foregroundColor(.white)
            .padding(.horizontal, 25)
            .padding(.vertical, 5)
            .frame(maxWidth: min(300, screenWidth * 0.8))
            .background(Capsule().fill(Color.white.opacity(0.1)))
            .overlay(Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1))
            .onAppear {
                isAnimating = true
            }
        }
    }
}
