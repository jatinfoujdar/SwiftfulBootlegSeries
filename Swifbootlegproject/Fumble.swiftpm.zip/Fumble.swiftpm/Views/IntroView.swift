import SwiftUI

struct IntroView: View {
    @Binding var hasSeenIntro: Bool
    @State private var showNext = false
    @State private var bounce = false
    
    var body: some View {
        ZStack {
            AmbientBackground()
                .overlay(Color.black.opacity(0.4))
            
            VStack(spacing: 30) {
                if !showNext {
                    VStack(spacing: 20) {
                        Text("Welcome to")
                            .font(.title2)
                            .foregroundColor(.white.opacity(0.8))
                        
                        FlipText(text: "Jumbly")
                            .scaleEffect(bounce ? 1.1 : 1.0)
                            .animation(.spring(response: 0.5, dampingFraction: 0.5).repeatForever(autoreverses: true), value: bounce)
                        
                        Text("Where messy is fun.")
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.7))
                    }
                    .transition(.asymmetric(insertion: .move(edge: .leading), removal: .move(edge: .trailing).combined(with: .opacity)))
                } else {
                    VStack(spacing: 25) {
                        Text("Liquid Logic")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .foregroundColor(.white)
                        
                        Text("Drag the letter droplets and watch them flow. When they touch, they bind with surface tension.")
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white.opacity(0.9))
                            .padding(.horizontal, 40)
                        
                        HStack(spacing: 20) {
                            Image(systemName: "hand.draw.fill")
                                .font(.system(size: 40))
                            Image(systemName: "iphone.radiowaves.left.and.right")
                                .font(.system(size: 40))
                        }
                        .foregroundColor(.blue)
                        
                        Text("Tip: Shake your device to reshuffle!")
                            .font(.subheadline)
                            .foregroundColor(.yellow)
                            .fontWeight(.bold)
                    }
                    .transition(.asymmetric(insertion: .move(edge: .trailing), removal: .opacity))
                }
                
                Button(action: {
                    withAnimation(.spring()) {
                        if showNext {
                            hasSeenIntro = true
                        } else {
                            showNext = true
                        }
                    }
                }) {
                    Text(showNext ? "LET'S FLOW" : "HOW IT WORKS")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.vertical, 15)
                        .padding(.horizontal, 40)
                        .background(Capsule().fill(Color.blue))
                        .shadow(radius: 10)
                }
            }
        }
        .onAppear {
            bounce = true
        }
    }
}
