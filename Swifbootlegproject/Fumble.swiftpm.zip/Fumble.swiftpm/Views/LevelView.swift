import SwiftUI
import UniformTypeIdentifiers

struct LevelView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var viewModel: GameViewModel
    @StateObject private var motionManager = MotionManager()
    
    @State private var letterPositions: [UUID: CGPoint] = [:]
    
    @State private var pulsePhase: CGFloat = 0
    @State private var dragVelocity: CGPoint = .zero
    @State private var lastDragLocation: CGPoint = .zero
    
    init(category: LevelCategory = .classic) {
        _viewModel = StateObject(wrappedValue: GameViewModel(category: category))
    }
    
    @State private var showWinMessage = false
    @State private var showTutorial = true

    var body: some View {
        GeometryReader { geometry in
            let screenWidth = geometry.size.width
            let screenHeight = geometry.size.height
            let letterCount = CGFloat(viewModel.currentLetters.count)
            let totalPadding = screenWidth * 0.08
            let adaptiveSpacing = letterCount > 5 ? max(8, screenWidth / 40) : max(15, screenWidth / 25)
            // Constrain letter size by both width and height to fit in landscape
            // Constrain letter size more aggressively for compact landscape
            let letterSize = min(70, min(screenHeight * 0.2, (screenWidth - totalPadding - (max(0, letterCount - 1) * adaptiveSpacing)) / max(1, letterCount)))

            
            ZStack {
                
            AmbientBackground(motionX: motionManager.x, motionY: motionManager.y)
                .overlay(Color.black.opacity(0.3))
            
            VStack(spacing: 5) { // Reduced spacing between header and game area
                // Header
                headerView(screenWidth: screenWidth, screenHeight: screenHeight)
                
                Spacer(minLength: 0)
                
                // Game Area
                ZStack(alignment: .center) {
                    
                    
                    DynamicLiquidBackground(letterPositions: computedPositions, letters: viewModel.currentLetters, baseSize: letterSize)
                        .frame(height: letterSize * 1.5) // Ensure height matches tiles container
                        .foregroundColor(Color.black.opacity(0.5))
//
                // Letters Container
                HStack(spacing: adaptiveSpacing) {
                    ForEach(Array(viewModel.currentLetters.enumerated()), id: \.element.id) { index, letter in
                        GeometryReader { geo in
                            LetterTile(letter: letter, size: letterSize, fontSize: letterSize * 0.6)
                                // Liquid-style scale with gentle pulsing
                                .scaleEffect(letterScale(for: letter, index: index))
                                // Liquid rotation based on drag velocity
                                .rotationEffect(letterRotation(for: letter))
                                // Enhanced shadow for depth
                                .shadow(color: .black.opacity(0.3), radius: viewModel.draggedLetter == letter ? 15 : 5, x: 0, y: viewModel.draggedLetter == letter ? 8 : 3)
                                // Hint glow effect
                                .shadow(color: isHinted(index: index) ? .yellow : .clear, radius: isHinted(index: index) ? 20 : 0)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(isHinted(index: index) ? Color.yellow : Color.clear, lineWidth: isHinted(index: index) ? 3 : 0)
                                        .scaleEffect(isHinted(index: index) ? 1.1 : 1.0)
                                        .animation(.spring(response: 0.6, dampingFraction: 0.6).repeatForever(autoreverses: true), value: viewModel.hintedLetterIndex)
                                )
                                .zIndex(viewModel.draggedLetter == letter ? 100 : 1)
                                .offset(offset(for: letter, geo: geo))
                                // Snake Jiggle Animation (only when not dragging)
                                .offset(y: viewModel.draggedLetter == letter ? 0 : snakeOffset(for: index))
                                // Motion blur effect during fast movement
                                .blur(radius: viewModel.draggedLetter == letter ? min(abs(dragVelocity.x + dragVelocity.y) / 100, 2) : 0)
                                .gesture(
                                    DragGesture(coordinateSpace: .named("GameArea"))
                                        .onChanged { value in
                                            // Calculate velocity for liquid effects
                                            let deltaX = value.location.x - (lastDragLocation == .zero ? value.startLocation.x : lastDragLocation.x)
                                            let deltaY = value.location.y - (lastDragLocation == .zero ? value.startLocation.y : lastDragLocation.y)
                                            
                                            withAnimation(.interactiveSpring(response: 0.25, dampingFraction: 0.65, blendDuration: 0.1)) {
                                                dragVelocity = CGPoint(x: deltaX, y: deltaY)
                                                lastDragLocation = value.location
                                                
                                                // Update model with absolute drag location
                                                viewModel.onDragChanged(letter: letter, location: value.location)
                                            }
                                            
                                            // Check for swaps with a small delay to avoid excessive state updates
                                            checkForSwap(activeLetter: letter)
                                        }
                                        .onEnded { _ in
                                            // Smooth elastic snap-back with interpolating spring
                                            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                                viewModel.onDragEnded()
                                                dragVelocity = .zero
                                                lastDragLocation = .zero
                                            }
                                        }
                                )
                                .animation(.spring(response: 0.4, dampingFraction: 0.7), value: viewModel.currentLetters)
                        }
                        .frame(width: letterSize, height: letterSize)
                        
                        // Track layout positions
                        .background(
                            GeometryReader { innerGeo in
                                Color.clear
                                    .preference(key: ViewOffsetKey.self, value: [letter.id: innerGeo.frame(in: .named("GameArea")).center])
                            }
                        )
                    }
                }
                .padding(.horizontal, max(10, screenWidth * 0.05))
                .frame(height: letterSize * 1.5) // Tighter vertical container
            }
            .coordinateSpace(name: "GameArea")
            .onPreferenceChange(ViewOffsetKey.self) { prefs in
                self.letterPositions = prefs
            }
            .frame(height: letterSize * 1.8) // Reduced from 2.25
            
            Spacer()
            
            // Tutorial Overlay
            if showTutorial && !viewModel.isGameOver {
                tutorialOverlay
            }
        }
        
        // Win Overlay
        if viewModel.isGameOver {
            winOverlay
        }
    }
    .navigationBarHidden(true)
    .onAppear {
        startSnakeAnimation()
        startPulseAnimation()
        
        motionManager.onShake = {
            viewModel.shuffleLetters()
        }
    }
    .onChange(of: viewModel.isGameOver) { gameOver in
        if gameOver {
            // Delay showing the message
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                withAnimation {
                    showWinMessage = true
                }
            }
        } else {
            showWinMessage = false
        }
    }
}
}

@State private var snakePhase: CGFloat = 0

func startSnakeAnimation() {
    withAnimation(.easeInOut(duration: 2.5).repeatForever(autoreverses: true)) {
        snakePhase = .pi * 0.5
    }
}

func startPulseAnimation() {
    withAnimation(.easeInOut(duration: 4.0).repeatForever(autoreverses: true)) {
        pulsePhase = .pi * 0.5
    }
}

func snakeOffset(for index: Int) -> CGFloat {
    // Sine wave based on index + phase
    // Amplitude 5, Frequency adjusted by index
    return sin(snakePhase + Double(index) * 0.5) * 5
}

func letterScale(for letter: Letter, index: Int) -> CGFloat {
    if viewModel.draggedLetter == letter {
        return 1.25 // Slightly larger when dragging
    } else {
        // Gentle breathing effect when idle
        let pulse = sin(pulsePhase + Double(index) * 0.3) * 0.03
        return 1.0 + pulse
    }
}

func letterRotation(for letter: Letter) -> Angle {
    if viewModel.draggedLetter == letter {
        // Rotate based on drag velocity for organic feel
        let rotation = atan2(dragVelocity.y, dragVelocity.x) * 0.1
        return .radians(Double(rotation))
    }
    return .zero
}

func isHinted(index: Int) -> Bool {
    return viewModel.hintedLetterIndex == index
}

var computedPositions: [UUID: CGPoint] {
    // For background effect
    var positions = letterPositions
    if let dragged = viewModel.draggedLetter, let _ = positions[dragged.id] {
        positions[dragged.id] = viewModel.dragLocation
    }
    return positions
}

func offset(for letter: Letter, geo: GeometryProxy) -> CGSize {
   
    
    if viewModel.draggedLetter == letter {
        let currentCenter = geo.frame(in: .named("GameArea")).center
        return CGSize(
            width: viewModel.dragLocation.x - currentCenter.x,
            height: viewModel.dragLocation.y - currentCenter.y
        )
    }
    return .zero
}

func checkForSwap(activeLetter: Letter) {
    guard let draggedLoc = viewModel.draggedLetter == activeLetter ? viewModel.dragLocation : nil else { return }
    

    for other in viewModel.currentLetters where other != activeLetter {
        if let pos = letterPositions[other.id] {
             let distance = hypot(draggedLoc.x - pos.x, draggedLoc.y - pos.y)
             if distance < 40 { // Slightly generous threshold
                 withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                     viewModel.reorder(from: activeLetter, to: other)
                 }
             }
        }
    }
}
    
    // Subviews
    func headerView(screenWidth: CGFloat, screenHeight: CGFloat) -> some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Level \(viewModel.currentLevel.id)")
                    .font(.subheadline) // Smaller label
                    .fontWeight(.bold)
                    .foregroundColor(.white.opacity(0.8))
                Text(viewModel.currentLevel.prompt)
                    .font(.system(size: viewModel.currentLevel.category == .emoji ? min(100, min(screenWidth / 3, screenHeight * 0.22)) : min(45, min(screenWidth / 8, screenHeight * 0.12)), weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.2)
                    .accessibilityLabel("Puzzle: \(viewModel.currentLevel.prompt)")
            }
            Spacer()
            
            HStack(spacing: 12) {
                // Hint button
                Button(action: {
                    SoundManager.shared.playMenuSelectSound()
                    viewModel.showHint()
                }) {
                    ZStack {
                        Image(systemName: "lightbulb.fill")
                            .font(.system(size: 18))
                            .foregroundColor(.yellow)
                        
                        // Hint count badge
                        if viewModel.hintsUsed > 0 {
                            Text("\(viewModel.hintsUsed)")
                                .font(.system(size: 9, weight: .bold))
                                .foregroundColor(.white)
                                .padding(3)
                                .background(Circle().fill(Color.red))
                                .offset(x: 10, y: -10)
                        }
                    }
                    .padding(8)
                    .background(Circle().fill(Color.white.opacity(0.2)))
                }
                .accessibilityLabel("Hint")
                .accessibilityHint("Get a hint for the next letter")
                
                Button(action: { 
                    SoundManager.shared.playHomeTapSound()
                    presentationMode.wrappedValue.dismiss() 
                }) {
                    Image(systemName: "house.fill")
                    .font(.system(size: 18))
                    .foregroundColor(.white)
                    .padding(8)
                    .background(Circle().fill(Color.white.opacity(0.2)))
                }
                .accessibilityLabel("Home")
                
                Button(action: { 
                    SoundManager.shared.playMenuSelectSound()
                }) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 18))
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Circle().fill(Color.white.opacity(0.2)))
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 10)
    }
    
    var tutorialOverlay: some View {
        ZStack {
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation { showTutorial = false }
                }
            
            VStack(spacing: 12) {
                HStack(spacing: 20) {
                    Image(systemName: "hand.draw.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.blue)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(viewModel.currentLevel.category == .emoji ? "Jumble the Emojis!" : "Fix the Jumble!")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("Drag the letters to their correct positions to reveal the secret word.")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.9))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.horizontal)
                
                Button(action: {
                    withAnimation { showTutorial = false }
                    SoundManager.shared.playMenuSelectSound()
                }) {
                    Text("START")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.vertical, 8)
                        .frame(maxWidth: 160)
                        .background(Capsule().fill(Color.blue))
                }
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 20).fill(Color.black.opacity(0.4)))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.2), lineWidth: 1))
            .padding(20)
        }
    }
    
    var winOverlay: some View {
        ZStack {
            ConfettiView()
                .ignoresSafeArea()
                .allowsHitTesting(false)
            
            if showWinMessage {
                Color.black.opacity(0.7)
                    .ignoresSafeArea()
                    .overlay(
                        VStack(spacing: 20) {
                            Text("Correct!")
                                .font(.largeTitle)
                                .fontWeight(.heavy)
                                .foregroundColor(.green)
                            
                            Button(action: {
                                SoundManager.shared.playMenuSelectSound()
                                viewModel.nextLevel()
                            }) {
                                Text("Next Level")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(width: 200)
                                    .background(Capsule().fill(Color.blue))
                            }
                        }
                    )
                    .transition(.opacity)
            }
        }
    }
}

extension CGRect {
    var center: CGPoint {
        CGPoint(x: midX, y: midY)
    }
}


extension Color {
    init(hex: String, opacity: Double = 1.0) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        let r = Double((rgb >> 16) & 0xFF) / 255.0
        let g = Double((rgb >> 8) & 0xFF) / 255.0
        let b = Double(rgb & 0xFF) / 255.0

        self.init(.sRGB, red: r, green: g, blue: b, opacity: opacity)
    }
}

#Preview {
    LevelView()
}
