import SwiftUI
import Combine

@MainActor
class GameViewModel: ObservableObject {
    @Published var currentLevel: Level
    @Published var currentLetters: [Letter] = []
    @Published var isGameOver: Bool = false
    @Published var shakeTrigger: Bool = false
    
    // Logic for drag
    @Published var draggedLetter: Letter?
    @Published var dragLocation: CGPoint = .zero // Absolute location in container
    
    // Hint system
    @Published var hintedLetterIndex: Int?
    @Published var hintsUsed: Int = 0
    
    private var levelsQueue: [Level] = []
    
    private let soundManager = SoundManager.shared
    
    init(category: LevelCategory = .classic) {
        // Load levels for the category
        self.levelsQueue = LevelData.getLevels(for: category)
        
        if let firstLevel = levelsQueue.first {
            self.currentLevel = firstLevel
        } else {
            // Fallback
             self.currentLevel = Level(id: 1, prompt: "No Levels", answer: "ERROR", category: .classic)
        }
        
        self.resetLevel()
    }
    
    func resetLevel() {
        self.currentLetters = currentLevel.scrambledLetters
        self.isGameOver = false
        self.hintedLetterIndex = nil
        self.hintsUsed = 0
    }

    func onDragChanged(letter: Letter, location: CGPoint) {
        if draggedLetter == nil {
            draggedLetter = letter
            soundManager.playLevelUpSound()

        }
        dragLocation = location
    }
    
    func onDragEnded() {
        // Reset
        draggedLetter = nil
        dragLocation = .zero
        soundManager.playDragEndSound()
        
        checkAnswer()
    }
    
    // Explicit reorder function usually called by drop or intersection logic
    func reorder(from source: Letter, to destination: Letter) {
         guard let fromIndex = currentLetters.firstIndex(of: source),
               let toIndex = currentLetters.firstIndex(of: destination) else { return }
         
         if fromIndex != toIndex {
             withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                 let movedLetter = currentLetters.remove(at: fromIndex)
                 currentLetters.insert(movedLetter, at: toIndex)
             }
             soundManager.playSwapSound()
             soundManager.playLevelUpSound() // Play level-up sound during letter flow
             checkAnswer()
         }
     }
    
    func moveLetter(from source: IndexSet, to destination: Int) {
        currentLetters.move(fromOffsets: source, toOffset: destination)
        soundManager.playMoveSound()
        checkAnswer()
    }
    
    func onDragReorder(from source: Letter, to destination: Letter) {
        // Keeps old functionality available just in case
        reorder(from: source, to: destination)
    }
    
    func checkAnswer() {
        let currentWord = currentLetters.map { $0.character }.joined()
        if currentWord == currentLevel.answer {
            isGameOver = true
            soundManager.playWinSound()
        }
    }
    
    func nextLevel() {
        // Find current index
        if let currentIndex = levelsQueue.firstIndex(where: { $0.id == currentLevel.id }) {
            let nextIndex = currentIndex + 1
            if nextIndex < levelsQueue.count {
                // Move to next level
                currentLevel = levelsQueue[nextIndex]
                resetLevel()
            } else {
                // Determine what to do at end of category. Loop back or finish?
                // For now, loop back to start
                currentLevel = levelsQueue[0]
                resetLevel()
            }
        }
    }
    
    // MARK: - Hint System
    
    func showHint() {
        // Find the first letter that's not in the correct position
        let correctLetters = Array(currentLevel.answer).map { String($0) }
        
        for (index, letter) in currentLetters.enumerated() {
            if index < correctLetters.count && letter.character != correctLetters[index] {
                // Found an incorrect letter
                hintedLetterIndex = index
                hintsUsed += 1
                
                // Clear hint after 3 seconds
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    self.clearHint()
                }
                
                // Play a subtle hint sound
                soundManager.playMenuSelectSound()
                return
            }
        }
    }
    
    func clearHint() {
        hintedLetterIndex = nil
    }
    
    func shuffleLetters() {
        withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
            currentLetters.shuffle()
        }
        soundManager.playMoveSound()
        checkAnswer()
    }
}
