//
//  Color.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import Foundation
import SwiftUI

extension Color {
    static let theme = Theme()
    
    // Task Color Palette
    static func taskColor(for index: Int) -> Color {
        let colors = [
            Color.blue,      // Ocean Blue
            Color.green,     // Forest Green
            Color.orange,    // Sunset Orange
            Color.purple,    // Royal Purple
            Color.red,       // Cherry Red
            Color.pink,      // Rose Pink
            Color.teal,      // Mint Teal
            Color.indigo,    // Deep Indigo
            Color.yellow,    // Golden Yellow
            Color.cyan,      // Sky Cyan
            Color.mint,      // Fresh Mint
            Color.brown      // Warm Brown
        ]
        return colors[index % colors.count]
    }
    
    static func taskGradient(for index: Int) -> LinearGradient {
        let baseColor = taskColor(for: index)
        return LinearGradient(
            colors: [
                baseColor.opacity(0.8),
                baseColor.opacity(0.6),
                baseColor.opacity(0.4)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
}

struct Theme {
    let background = Color("Background")
    let ocean = Color("Ocean")
    let secondaryText = Color("SecondaryText")
    let secondaryAccent = Color("SecondaryAccent")
    let darkBackground = Color("DarkBackground")
    
    // Modern gradient backgrounds
    let primaryGradient = LinearGradient(
        colors: [Color.blue.opacity(0.1), Color.purple.opacity(0.1)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    let accentGradient = LinearGradient(
        colors: [Color.accentColor.opacity(0.2), Color.accentColor.opacity(0.1)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}
