//
//  Week.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import Foundation

struct Week: Identifiable {
    var id: Int 
    var date: [Date]
}
