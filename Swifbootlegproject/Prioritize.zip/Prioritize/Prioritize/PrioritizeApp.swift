//
//  PrioritizeApp.swift
//  Prioritize
//
//  Created by jatin foujdar on 11/10/25.
//

import SwiftUI
import SwiftData

@main
struct PrioritizeApp: App {
    
    var body: some Scene {
        WindowGroup {
           TaskView()
        }
        .modelContainer(for: Task.self)
    }
}
