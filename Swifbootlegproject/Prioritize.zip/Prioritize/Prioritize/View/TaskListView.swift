//
//  TaskListView.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import SwiftUI
import SwiftData

struct TaskListView: View {
    @Binding var date: Date
    @Query private var allTasks: [Task]
    
    private var filteredTasks: [Task] {
        let calendar = Calendar.current
        let startDate = calendar.startOfDay(for: date)
        let endDate = calendar.date(byAdding: .day, value: 1, to: startDate)!
        
        return allTasks.filter { task in
            task.date >= startDate && task.date < endDate
        }.sorted { $0.date < $1.date }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if filteredTasks.isEmpty {
                // Empty state with modern design
                VStack(spacing: 20) {
                    Image(systemName: "checkmark.circle")
                        .font(.system(size: 60, weight: .light))
                        .foregroundColor(.secondary.opacity(0.6))
                    
                    Text("No tasks for \(date.formatted(.dateTime.weekday(.wide)))")
                        .font(.system(.title3, design: .rounded, weight: .semibold))
                        .foregroundColor(.secondary)
                    
                    Text("Tap the + button to add your first task")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.secondary.opacity(0.8))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.top, 100)
            } else {
                ForEach(filteredTasks) { task in
                    TaskItemView(task: task)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

#Preview {
    TaskListView(date: .constant(Date()))
        .modelContainer(for: Task.self)
}
