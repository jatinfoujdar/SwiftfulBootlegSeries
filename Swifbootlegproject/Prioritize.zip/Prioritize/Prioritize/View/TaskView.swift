//
//  TaskView.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import SwiftUI
import SwiftData

struct TaskView: View {
    @StateObject var viewModel = TaskViewModel()
    @State private var createNewTask: Bool = false
    @State var currentDate: Date = .init()
        
    var body: some View {
        NavigationStack {
            ZStack {
                // Background gradient
                Color.theme.primaryGradient
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 0) {
                    // Date header with enhanced styling
                    VStack(alignment: .leading, spacing: 8) {
                        Text(self.viewModel.currentDate.formatted(.dateTime.year().month(.wide).day().weekday(.wide)))
                            .font(.system(.subheadline, design: .rounded, weight: .semibold))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 20)
                            .padding(.top, 10)
                        
                        // Enhanced week header
                        WeekHeaderView(viewModel: viewModel)
                            .frame(height: 95)
                            .background(
                                RoundedRectangle(cornerRadius: 20, style: .continuous)
                                    .fill(.ultraThinMaterial)
                                    .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                            )
                            .padding(.horizontal, 16)
                    }
                    
                    // Task list with enhanced styling
                    ScrollView(.vertical, showsIndicators: false) {
                        LazyVStack(spacing: 0) {
                            TaskListView(date: $viewModel.currentDate)
                        }
                        .padding(.top, 20)
                    }
                    .background(Color.clear)
                }
                .toolbar {
                    ToolbarItem(placement: .navigation) {
                        HStack(spacing: 4) {
                            Text(self.viewModel.currentDate.formatted(.dateTime.month(.wide)))
                                .font(.system(.largeTitle, design: .rounded, weight: .bold))
                                .foregroundColor(.primary)
                            Text(self.viewModel.currentDate.formatted(.dateTime.year()))
                                .font(.system(.largeTitle, design: .rounded, weight: .bold))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    ToolbarItem(placement: .topBarTrailing) {
                        Button(action: {
                            withAnimation(.bouncy(duration: 0.4)) {
                                createNewTask = true
                            }
                        }, label: {
                            ZStack {
                                Circle()
                                    .fill(Color.accentColor)
                                    .frame(width: 32, height: 32)
                                    .shadow(color: .accentColor.opacity(0.3), radius: 4, x: 0, y: 2)
                                
                                Image(systemName: "plus")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                            }
                        })
                        .scaleEffect(createNewTask ? 1.1 : 1.0)
                        .sheet(isPresented: $createNewTask) {
                            TaskSheetView()
                                .presentationDetents([.fraction(0.85)])
                                .presentationBackground(.regularMaterial)
                                .presentationCornerRadius(25)
                                .presentationDragIndicator(.visible)
                        }
                    }
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

#Preview {
    NavigationView {
        TaskView()
            .modelContainer(for: Task.self)
    }
}
