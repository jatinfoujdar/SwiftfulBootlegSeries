//
//  TaskItemView.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import SwiftUI
import SwiftData

struct TaskItemView: View {
    @Bindable var task: Task
    @Environment(\.modelContext) private var context
    
    @State private var offset = CGSize.zero
    @State private var isSwipingToDelete = false
    @State private var isPressed = false
    
    private var taskColor: Color {
        Color.taskColor(for: task.colorIndex)
    }
    
    private var taskGradient: LinearGradient {
        Color.taskGradient(for: task.colorIndex)
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Color indicator with modern design
            ZStack {
                Circle()
                    .fill(taskGradient)
                    .frame(width: 16, height: 16)
                    .shadow(color: taskColor.opacity(0.3), radius: 4, x: 0, y: 2)
                
                if task.isCompleted {
                    Image(systemName: "checkmark")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white)
                        .scaleEffect(isPressed ? 0.8 : 1.0)
                }
            }
            .padding(.leading, 8)
            
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(task.title)
                        .font(.system(.headline, design: .rounded, weight: .semibold))
                        .foregroundColor(task.isCompleted ? .secondary : .primary)
                        .strikethrough(task.isCompleted)
                        .lineLimit(2)
                    
                    Spacer()
                    
                    // Priority indicator
                    Circle()
                        .fill(taskColor.opacity(0.2))
                        .frame(width: 8, height: 8)
                        .overlay(
                            Circle()
                                .stroke(taskColor, lineWidth: 1)
                        )
                }
                
                HStack {
                    Image(systemName: "clock")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(taskColor)
                    
                    Text(task.date.format("hh:mm a"))
                        .font(.system(.subheadline, design: .rounded, weight: .medium))
                        .foregroundColor(.secondary)
                }
                .strikethrough(task.isCompleted)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 16)
            .padding(.horizontal, 20)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        isSwipingToDelete ? 
                        Color.red.opacity(0.8) :
                        task.isCompleted ? 
                        Color.secondary.opacity(0.1) :
                        Color(.systemBackground)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(
                                isSwipingToDelete ? Color.red : taskColor.opacity(0.3),
                                lineWidth: isSwipingToDelete ? 2 : 1
                            )
                    )
                    .shadow(
                        color: isSwipingToDelete ? .red.opacity(0.3) : taskColor.opacity(0.1),
                        radius: isSwipingToDelete ? 8 : 6,
                        x: 0,
                        y: isSwipingToDelete ? 4 : 3
                    )
            )
            .scaleEffect(isPressed ? 0.98 : 1.0)
            .onTapGesture {
                withAnimation(.bouncy(duration: 0.6)) {
                    isPressed = true
                    task.isCompleted.toggle()
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation(.bouncy(duration: 0.4)) {
                        isPressed = false
                    }
                }
            }
            .opacity(2 - Double(abs(offset.width / 90)))
            .gesture(
                DragGesture(minimumDistance: 10)
                .onChanged { gesture in
                    withAnimation(.easeInOut(duration: 0.2)) {
                        offset = gesture.translation
                        isSwipingToDelete = true
                    }
                }
                .onEnded { gesture in
                    withAnimation(.bouncy(duration: 0.5)) {
                        isSwipingToDelete = false
                        offset = .zero
                        
                        if gesture.translation.width < -100 {
                            context.delete(task)
                        }
                    }
                })
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 20)
    }
}


#Preview {
    let config = ModelConfiguration(isStoredInMemoryOnly: true)
    let container = try! ModelContainer(for: Task.self, configurations: config)
    
    let task = Task(title: "Example Task", date: Date())
    
    return TaskItemView(task: task)
        .modelContainer(container)
}
