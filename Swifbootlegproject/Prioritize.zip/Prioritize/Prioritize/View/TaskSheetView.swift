//
//  TaskSheetView.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import SwiftUI
import SwiftData

struct TaskSheetView: View {
    @State private var taskTitle: String = ""
    @State private var taskDate: Date = .init()
    @State private var selectedColorIndex: Int = Int.random(in: 0..<12)
    
    @Environment(\.dismiss) var dismiss
    @Environment(\.modelContext) private var context
    
    private let colorOptions = Array(0..<12)
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            HStack {
                Button("Cancel") {
                    dismiss()
                }
                .font(.system(.body, design: .rounded, weight: .medium))
                .foregroundColor(.secondary)
                
                Spacer()
                
                Text("New Task")
                    .font(.system(.title2, design: .rounded, weight: .bold))
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button {
                    addTask()
                } label: {
                    Text("Add")
                        .font(.system(.body, design: .rounded, weight: .semibold))
                        .foregroundColor(.accentColor)
                }
                .disabled(taskTitle.isEmpty)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 20)
            
            Divider()
                .background(Color.secondary.opacity(0.3))
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Task Title Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Task Title")
                            .font(.system(.headline, design: .rounded, weight: .semibold))
                            .foregroundColor(.primary)
                        
                        TextField("Enter your task title", text: $taskTitle)
                            .font(.system(.body, design: .rounded))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color(.systemGray6))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.taskColor(for: selectedColorIndex).opacity(0.3), lineWidth: 1)
                                    )
                            )
                    }
                    
                    // Task Date Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Date & Time")
                            .font(.system(.headline, design: .rounded, weight: .semibold))
                            .foregroundColor(.primary)
                        
                        DatePicker("", selection: $taskDate)
                            .datePickerStyle(.compact)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color(.systemGray6))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.taskColor(for: selectedColorIndex).opacity(0.3), lineWidth: 1)
                                    )
                            )
                    }
                    
                    // Color Selection Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Choose Color")
                            .font(.system(.headline, design: .rounded, weight: .semibold))
                            .foregroundColor(.primary)
                        
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 6), spacing: 12) {
                            ForEach(colorOptions, id: \.self) { colorIndex in
                                Button {
                                    withAnimation(.bouncy(duration: 0.3)) {
                                        selectedColorIndex = colorIndex
                                    }
                                } label: {
                                    ZStack {
                                        Circle()
                                            .fill(Color.taskGradient(for: colorIndex))
                                            .frame(width: 40, height: 40)
                                            .shadow(color: Color.taskColor(for: colorIndex).opacity(0.3), radius: 4, x: 0, y: 2)
                                        
                                        if selectedColorIndex == colorIndex {
                                            Circle()
                                                .stroke(Color.primary, lineWidth: 3)
                                                .frame(width: 40, height: 40)
                                            
                                            Image(systemName: "checkmark")
                                                .font(.system(size: 14, weight: .bold))
                                                .foregroundColor(.white)
                                        }
                                    }
                                }
                                .scaleEffect(selectedColorIndex == colorIndex ? 1.1 : 1.0)
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                    
                    // Preview Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Preview")
                            .font(.system(.headline, design: .rounded, weight: .semibold))
                            .foregroundColor(.primary)
                        
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.taskGradient(for: selectedColorIndex))
                                    .frame(width: 16, height: 16)
                                    .shadow(color: Color.taskColor(for: selectedColorIndex).opacity(0.3), radius: 4, x: 0, y: 2)
                            }
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(taskTitle.isEmpty ? "Your Task Title" : taskTitle)
                                    .font(.system(.headline, design: .rounded, weight: .semibold))
                                    .foregroundColor(.primary)
                                    .opacity(taskTitle.isEmpty ? 0.5 : 1.0)
                                
                                HStack {
                                    Image(systemName: "clock")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(Color.taskColor(for: selectedColorIndex))
                                    
                                    Text(taskDate.format("hh:mm a"))
                                        .font(.system(.subheadline, design: .rounded, weight: .medium))
                                        .foregroundColor(.secondary)
                                }
                            }
                            
                            Spacer()
                        }
                        .padding(.vertical, 16)
                        .padding(.horizontal, 20)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color(.systemBackground))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(Color.taskColor(for: selectedColorIndex).opacity(0.3), lineWidth: 1)
                                )
                                .shadow(
                                    color: Color.taskColor(for: selectedColorIndex).opacity(0.1),
                                    radius: 6, x: 0, y: 3
                                )
                        )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 100)
            }
        }
        .background(Color(.systemBackground))
        .preferredColorScheme(.dark)
    }
    
    private func addTask() {
        let task = Task(
            title: taskTitle,
            date: taskDate,
            colorIndex: selectedColorIndex
        )
        
        do {
            context.insert(task)
            try context.save()
            dismiss()
        } catch {
            print(error.localizedDescription)
        }
    }
}

#Preview {
    TaskSheetView()
}
