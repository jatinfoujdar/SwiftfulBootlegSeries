//
//  WeekHeaderView.swift
//  TaskPlanner
//
//  Created by jatin foujdar on 19/04/2024.
//

import SwiftUI

struct WeekHeaderView: View {
    @ObservedObject var viewModel: TaskViewModel
    @State private var snappedItem = 0.0
    @State private var draggingItem = 0.0
    
    var body: some View {
        TabView(selection: $viewModel.currentIndex) {
            ForEach(viewModel.allWeeks) { week in
                VStack {
                    HStack(spacing: 4) {
                        ForEach(0..<7) { index in
                            VStack(spacing: 6) {
                                // Day name
                                Text(viewModel.dateToString(date: week.date[index], format: "E"))
                                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                                    .foregroundColor(viewModel.isCurrentDate(week.date[index], viewModel.currentDate) ? .primary : .secondary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.8)

                                // Date number
                                ZStack {
                                    Text(viewModel.dateToString(date: week.date[index], format: "dd"))
                                        .font(.system(size: 14, weight: .bold, design: .rounded))
                                        .foregroundColor(viewModel.isCurrentDate(week.date[index], viewModel.currentDate) ? .white : .primary)
                                        .frame(width: 28, height: 28)
                                        .background {
                                            if viewModel.isCurrentDate(week.date[index], viewModel.currentDate) {
                                                Circle()
                                                    .fill(Color.accentColor)
                                                    .shadow(color: .accentColor.opacity(0.3), radius: 3, x: 0, y: 2)
                                            } else if viewModel.isToday(date: week.date[index]) {
                                                Circle()
                                                    .stroke(Color.accentColor, lineWidth: 2)
                                            }
                                        }
                                }
                            }
                            .frame(width: (UIScreen.main.bounds.width - 32) / 7, alignment: .center)
                            .onTapGesture {
                                withAnimation(.bouncy(duration: 0.4)) {
                                    viewModel.currentDate = week.date[index]
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .frame(height: 85)
                }
                .tag(week.id) // make sure week.id matches viewModel.currentIndex
                .frame(maxWidth: .infinity, alignment: .top)
                .padding()
            }
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
        .gesture(
            DragGesture()
                .onChanged { value in
                    withAnimation(.snappy) {
                        draggingItem = snappedItem + value.translation.width / 400
                    }
                }
                .onEnded { value in
                    withAnimation(.snappy) {
                        if value.predictedEndTranslation.width > 0 {
                            draggingItem = snappedItem + 1
                        } else {
                            draggingItem = snappedItem - 1
                        }
                        snappedItem = draggingItem
                        viewModel.update(index: Int(snappedItem))
                    }
                }
        )
        .onAppear {
            viewModel.currentIndex = min(max(viewModel.currentIndex, 0), viewModel.allWeeks.count - 1)
        }
        .preferredColorScheme(.dark)
    }
    
    func distance(_ item: Int) -> Double {
        return (draggingItem - Double(item)).remainder(dividingBy: Double(viewModel.allWeeks.count))
    }
    
    func screenOffset(_ item: Int) -> Double {
        let angle = Double.pi * 2 / Double(viewModel.allWeeks.count) * distance(item)
        return sin(angle) * 200
    }
}

#Preview {
    WeekHeaderView(viewModel: TaskViewModel())
}
