//
//  JumblifyApp.swift
//  Jumblify
//
//  Created by jatin foujdar on 25/12/25.
//

import SwiftUI

@main
struct JumblifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
