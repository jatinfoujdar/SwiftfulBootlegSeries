import SwiftUI
import Combine

class GameViewModel: ObservableObject {
    @Published var currentLevel: Level
    @Published var currentLetters: [Letter] = []
    @Published var isGameOver: Bool = false
    @Published var shakeTrigger: Bool = false
    
    // Logic for drag
    @Published var draggedLetter: Letter?
    @Published var dragLocation: CGPoint = .zero // Absolute location in container
    
    private var levelsQueue: [Level] = []
    
    private let soundManager = SoundManager.shared
    
    init(category: LevelCategory = .classic) {
        // Load levels for the category
        self.levelsQueue = LevelData.getLevels(for: category)
        
        if let firstLevel = levelsQueue.first {
            self.currentLevel = firstLevel
        } else {
            // Fallback
             self.currentLevel = Level(id: 1, prompt: "No Levels", answer: "ERROR", category: .classic)
        }
        
        self.resetLevel()
    }
    
    func resetLevel() {
        self.currentLetters = currentLevel.scrambledLetters
        self.isGameOver = false
    }

    func onDragChanged(letter: Letter, location: CGPoint) {
        if draggedLetter == nil {
            draggedLetter = letter
            soundManager.playDragStartSound()
        }
        dragLocation = location
    }
    
    func onDragEnded() {
        // Reset
        draggedLetter = nil
        dragLocation = .zero
        soundManager.playDragEndSound()
        
        checkAnswer()
    }
    
    // Explicit reorder function usually called by drop or intersection logic
    func reorder(from source: Letter, to destination: Letter) {
         guard let fromIndex = currentLetters.firstIndex(of: source),
               let toIndex = currentLetters.firstIndex(of: destination) else { return }
         
         if fromIndex != toIndex {
             withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                 let movedLetter = currentLetters.remove(at: fromIndex)
                 currentLetters.insert(movedLetter, at: toIndex)
             }
             soundManager.playSwapSound()
         }
     }
    
    func moveLetter(from source: IndexSet, to destination: Int) {
        currentLetters.move(fromOffsets: source, toOffset: destination)
        soundManager.playMoveSound()
        checkAnswer()
    }
    
    func onDragReorder(from source: Letter, to destination: Letter) {
        // Keeps old functionality available just in case
        reorder(from: source, to: destination)
    }
    
    func checkAnswer() {
        let currentWord = currentLetters.map { $0.character }.joined()
        if currentWord == currentLevel.answer {
            isGameOver = true
            soundManager.playWinSound()
        }
    }
    
    func nextLevel() {
        // Find current index
        if let currentIndex = levelsQueue.firstIndex(where: { $0.id == currentLevel.id }) {
            let nextIndex = currentIndex + 1
            if nextIndex < levelsQueue.count {
                // Move to next level
                currentLevel = levelsQueue[nextIndex]
                resetLevel()
            } else {
                // Determine what to do at end of category. Loop back or finish?
                // For now, loop back to start
                currentLevel = levelsQueue[0]
                resetLevel()
            }
        }
    }
}
