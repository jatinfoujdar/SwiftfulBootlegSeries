import CoreMotion
import SwiftUI
import Combine

class MotionManager: ObservableObject {
    private let motionManager = CMMotionManager()
    @Published var x: Double = 0.0
    @Published var y: Double = 0.0
    
    init() {
        startAccelerometers()
    }
    
    func startAccelerometers() {
        if motionManager.isAccelerometerAvailable {
            motionManager.accelerometerUpdateInterval = 1/60.0
            motionManager.startAccelerometerUpdates(to: .main) { [weak self] data, error in
                guard let data = data else { return }
                
                // Low pass filter or just direct mapping
                // Using withAnimation to smooth it slightly if needed, but direct is faster
                withAnimation(.linear(duration: 0.1)) {
                    self?.x = data.acceleration.x
                    self?.y = data.acceleration.y
                }
            }
        }
    }
    
    func stopAccelerometers() {
        motionManager.stopAccelerometerUpdates()
    }
}
