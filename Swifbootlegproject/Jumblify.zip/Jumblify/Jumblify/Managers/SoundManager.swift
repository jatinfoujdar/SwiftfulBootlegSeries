import Foundation
import AVFoundation
import UIKit


class SoundManager {
    static let shared = SoundManager()
    
    // System sound IDs
    private let tapSoundID: SystemSoundID = 1057    // For home icon / general tap
    private let selectSoundID: SystemSoundID = 1105 // For category select
    private let backSoundID: SystemSoundID = 1052   // For back button
    private let dragStartSoundID: SystemSoundID = 1123
    private let dragEndSoundID: SystemSoundID = 1124
    private let swapSoundID: SystemSoundID = 1103
    private let moveSoundID: SystemSoundID = 1104
    private let logoSoundID: SystemSoundID = 1101
    private let teddySoundID: SystemSoundID = 1023 // Playful sound for flipping
    
    private init() {}
    
    func playTeddySound() {
        AudioServicesPlaySystemSound(teddySoundID)
    }
    
    func playLogoTapSound() {
        AudioServicesPlaySystemSound(logoSoundID)
    }
    
    func playHomeTapSound() {
        AudioServicesPlaySystemSound(tapSoundID)
    }
    
    func playMenuSelectSound() {
        AudioServicesPlaySystemSound(selectSoundID)
    }
    
    func playBackSound() {
        AudioServicesPlaySystemSound(backSoundID)
    }
    
    func playDragStartSound() {
        AudioServicesPlaySystemSound(dragStartSoundID)
    }
    
    func playDragEndSound() {
        AudioServicesPlaySystemSound(dragEndSoundID)
    }
    
    func playSwapSound() {
        AudioServicesPlaySystemSound(swapSoundID)
    }
    
    func playMoveSound() {
        AudioServicesPlaySystemSound(moveSoundID)
    }
    
    func playWinSound() {
        // Haptic feedback for win
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        
        // Success sound
        AudioServicesPlaySystemSound(1022) // "Sent Mail" sound as success indicator
    }
}
