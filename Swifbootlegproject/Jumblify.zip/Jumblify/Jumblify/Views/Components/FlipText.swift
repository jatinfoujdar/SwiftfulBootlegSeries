import SwiftUI

struct FlipText: View {
    let text: String
    @State private var flip = false
    
    var body: some View {
        HStack(spacing: 2) { // Tight spacing for word-like appearance
            ForEach(Array(text.enumerated()), id: \.offset) { index, char in
                Text(String(char))
                    .font(.system(size: 95, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .rotation3DEffect(
                        .degrees(flip ? 0 : -90),
                        axis: (x: 1, y: 0, z: 0)
                    )
                    .opacity(flip ? 1 : 0) // Fade in combined with flip
                    .animation(
                        .spring(response: 0.4, dampingFraction: 0.7, blendDuration: 0.6)
                        .delay(Double(index) * 0.2), // Staggered delay
                        value: flip
                    )
            }
        }
        .onTapGesture {
            SoundManager.shared.playLogoTapSound()
            flip = false
            // Stagger the reset and replay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                flip = true
                playFlipSounds()
            }
        }
        .onAppear {
            // Ensure we start from false and flip to true after a tiny delay
            flip = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                flip = true
                playFlipSounds()
            }
        }
    }
    
    private func playFlipSounds() {
        for index in 0..<text.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.2) {
                SoundManager.shared.playTeddySound()
            }
        }
    }
}

struct FlipText_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.black
            FlipText(text: "Jumblify")
        }
    }
}
