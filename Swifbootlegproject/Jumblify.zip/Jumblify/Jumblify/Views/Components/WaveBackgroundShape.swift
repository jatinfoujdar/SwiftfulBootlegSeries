import SwiftUI

struct WaveBackgroundShape: Shape {
    let letterCount: Int
    let circleSize: CGFloat = 60
    let spacing: CGFloat = 10 // Overlap amount (negative spacing effectively)
    
    // We want the circles to "blob" together. 
    // A simple way to achieve the look in the screenshot is to draw circles and connect them with smooth curves.
    // Ideally we would use a layout engine, but a Shape is requested.
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        guard letterCount > 0 else { return path }
        
        let totalWidth = rect.width
        let circleRadius = rect.height / 2
        
        // Ensure we fit
        // In the screenshot, it looks like a single fused blob.
        // Let's approximate with a rounded rectangle with very large corner radius, 
        // but that doesn't give the "humps".
        // To get the humps, we can draw a series of circles.
        
        let step = totalWidth / CGFloat(letterCount)
        
        for i in 0..<letterCount {
            let center = CGPoint(x: step * CGFloat(i) + step / 2, y: rect.height / 2)
            path.addEllipse(in: CGRect(x: center.x - circleRadius, y: center.y - circleRadius, width: circleRadius * 2, height: circleRadius * 2))
        }
        
        // To make them "connected" smoothly like metaballs, we usually rely on SwiftUI filters 
        // or complex Bezier paths. For the "Shape" itself, returning just the circles might be enough 
        // if we apply a blur/threshold in the View interactively.
        // HOWEVER, drawing a unified path is better for stroke/shadow.
        
        // Simplified approach: Rounded Rectangle for now, as calculating the perfect tangent arcs for N circles 
        // is mathematically involved for a one-shot tool.
        // Wait, I can try to make it a bit more "blobby" by using the metaball liquid filter trick in the View instead of the Shape.
        
        return path
    }
}

// Helper view to render the "Liquid" blob effect
struct LiquidBlobView: View {
    let letterCount: Int
    var color: Color = .black.opacity(0.8)
    
    var body: some View {
        Canvas { context, size in
            let circleSize = size.height
            let step = size.width / CGFloat(letterCount)
            
            context.addFilter(.alphaThreshold(min: 0.5, color: color))
            context.addFilter(.blur(radius: 10))
            
            context.drawLayer { ctx in
                for i in 0..<letterCount {
                    let center = CGPoint(x: step * CGFloat(i) + step / 2, y: size.height / 2)
                    let rect = CGRect(x: center.x - circleSize/2, y: center.y - circleSize/2, width: circleSize, height: circleSize)
                    ctx.fill(Circle().path(in: rect), with: .color(color))
                    
                    // Add connectors
                    if i < letterCount - 1 {
                        let nextCenter = CGPoint(x: step * CGFloat(i+1) + step / 2, y: size.height / 2)
                        let midRect = CGRect(x: center.x, y: center.y - circleSize/2 + 10, width: nextCenter.x - center.x, height: circleSize - 20)
                         ctx.fill(Rectangle().path(in: midRect), with: .color(color))
                    }
                }
            }
        }
    }
}
