import SwiftUI

struct DynamicLiquidBackground: View {
    let letterPositions: [UUID: CGPoint]
    let letters: [Letter] // To know the order and ID
    
    var body: some View {
        Canvas { context, size in
            let circleRadius: CGFloat = 55 // Larger radius for 80pt tiles
            
            // Draw all circles
            context.addFilter(.alphaThreshold(min: 0.5, color: .black.opacity(0.6)))
            context.addFilter(.blur(radius: 15)) // Increased blur for smoother meld
            
            context.drawLayer { ctx in
                var points: [CGPoint] = []
                
                // Collect points in order
                for letter in letters {
                    if let pos = letterPositions[letter.id] {
                        points.append(pos)
                    }
                }
                
                for point in points {
                    let rect = CGRect(x: point.x - circleRadius, y: point.y - circleRadius, width: circleRadius * 2, height: circleRadius * 2)
                    ctx.fill(Circle().path(in: rect), with: .color(.black.opacity(0.6)))
                }
                
                // Connect neighbors if close enough
                for i in 0..<points.count {
                    for j in i+1..<points.count {
                        let p1 = points[i]
                        let p2 = points[j]
                        let dist = hypot(p2.x - p1.x, p2.y - p1.y)
                        
                        if dist < 150 { // Increased max connection distance
                            let path = Path { p in
                                p.move(to: p1)
                                p.addLine(to: p2)
                            }
                            ctx.stroke(path, with: .color(.black.opacity(0.6)), lineWidth: circleRadius * 2)
                        }
                    }
                }
            }
        }
    }
}
