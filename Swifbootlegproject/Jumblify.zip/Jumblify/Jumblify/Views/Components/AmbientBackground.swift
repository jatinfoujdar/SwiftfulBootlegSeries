import SwiftUI

struct AmbientBackground: View {
    @StateObject private var motion = MotionManager()

    @State private var start = UnitPoint(x: 0, y: -2)
    @State private var end   = UnitPoint(x: 4, y: 0)

    @State private var hue: Double = 0.0
    @State private var time: Double = 0.0

    var body: some View {
        ZStack {
            // Base liquid layer
            LinearGradient(
                gradient: Gradient(
                    colors: AmbientPaletteGenerator.generate(
                        baseHue: hue,
                        time: time,
                        motion: motion
                    )
                ),
                startPoint: effectiveStart,
                endPoint: effectiveEnd
            )
            .blur(radius: 80)

            // Depth layer (adds richness)
            LinearGradient(
                gradient: Gradient(
                    colors: AmbientPaletteGenerator.generate(
                        baseHue: hue + 0.18,
                        time: time * 1.3,
                        motion: motion
                    )
                ),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .blendMode(.plusLighter)
            .blur(radius: 100)
        }
        .ignoresSafeArea()
        .onAppear {
            // Gradient direction motion
            withAnimation(
                .easeInOut(duration: 25) // Slower, deeper motion
                .repeatForever(autoreverses: true)
            ) {
                start = UnitPoint(x: 3, y: 1)
                end   = UnitPoint(x: -1, y: 4)
            }

            // 🌈 Infinite hue cycle - Slow and subtle
            withAnimation(
                .linear(duration: 120) // Very long cycle (2 minutes)
                .repeatForever(autoreverses: false)
            ) {
                hue = 1.0
            }

            // 🌊 Liquid time flow
            withAnimation(
                .linear(duration: 40) // Smooth, viscous flow
                .repeatForever(autoreverses: false)
            ) {
                time = 1.0
            }
        }
    }

    private var effectiveStart: UnitPoint {
        UnitPoint(
            x: start.x + motion.x * 1.5,
            y: start.y + motion.y * 1.5
        )
    }

    private var effectiveEnd: UnitPoint {
        UnitPoint(
            x: end.x - motion.x * 1.5,
            y: end.y - motion.y * 1.5
        )
    }
}


struct AmbientPaletteGenerator {

    static func generate(
        baseHue: Double,
        time: Double,
        motion: MotionManager
    ) -> [Color] {

        func hue(_ offset: Double) -> Double {
            (baseHue
             + offset
             + time * 0.1
             + motion.x * 0.05
            ).truncatingRemainder(dividingBy: 1)
        }

        // Dark, moody, premium palette logic
        // Low brightness, deep saturation
        return [
            Color(hue: hue(0.0),  saturation: 0.8, brightness: 0.30), // Deep base
            Color(hue: hue(0.1),  saturation: 0.9, brightness: 0.20), // Darker accent
            Color(hue: hue(0.25), saturation: 0.8, brightness: 0.35), // Mid tone
            Color(hue: hue(0.4),  saturation: 0.9, brightness: 0.15), // Shadow
            Color(hue: hue(0.6),  saturation: 0.8, brightness: 0.25), // Deep aesthetic
            Color(hue: hue(0.75), saturation: 0.9, brightness: 0.40)  // "Highlight" (still dark)
        ]
    }
}

