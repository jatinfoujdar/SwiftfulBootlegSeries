import SwiftUI

struct ConfettiView: View {
    @State private var animate = false
    
    var body: some View {
        ZStack {
            ForEach(0..<50) { _ in
                ConfettiPiece()
            }
        }
        .onAppear {
            animate = true
        }
    }
}

struct ConfettiPiece: View {
    @State private var xStart: CGFloat = CGFloat.random(in: 0...10)
    @State private var yStart: CGFloat = CGFloat.random(in: -500...0)
    @State private var rotation: Double = Double.random(in: 0...360)
    @State private var color: Color = [Color.red, .blue, .green, .yellow, .purple, .orange].randomElement()!
    
    var body: some View {
        Rectangle()
            .fill(color)
            .frame(width: 10, height: 10)
            .position(x: CGFloat.random(in: 0...UIScreen.main.bounds.width), y: yStart)
            .rotationEffect(.degrees(rotation))
            .onAppear {
                withAnimation(Animation.linear(duration: Double.random(in: 2...5)).repeatForever(autoreverses: false)) {
                    yStart = UIScreen.main.bounds.height + 50
                    rotation += 180
                }
            }
    }
}
