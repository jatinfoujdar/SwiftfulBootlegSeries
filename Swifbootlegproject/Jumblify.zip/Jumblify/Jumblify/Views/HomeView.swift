import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Background
                // Background
                AmbientBackground()
                    .overlay(Color.black.opacity(0.3)) // Slight overlay for consistency
                
                VStack(spacing: 20) {
                    Spacer()
                    
                    FlipText(text: "Jumblify")
                        .padding(.bottom, 40)
                        .accessibilityLabel("Jumblify Game")
                        .accessibilityAddTraits(.isHeader)
                    
                    NavigationLink(destination: LevelView(category: .classic)) {
                        MenuButton(title: "CLASSIC", icon: "gamecontroller.fill", index: 0)
                    }
                    .simultaneousGesture(TapGesture().onEnded {
                        SoundManager.shared.playMenuSelectSound()
                    })
                    .accessibilityLabel("Classic Category")
                    .accessibilityHint("Play levels with classic word jumbles")
                    
                    NavigationLink(destination: LevelView(category: .riddle)) {
                        MenuButton(title: "RIDDLE", icon: "questionmark.circle.fill", index: 1)
                    }
                    .simultaneousGesture(TapGesture().onEnded {
                        SoundManager.shared.playMenuSelectSound()
                    })
                    .accessibilityLabel("Riddle Category")
                    .accessibilityHint("Play levels with word riddles")
                    
                    NavigationLink(destination: LevelView(category: .emoji)) {
                        MenuButton(title: "EMOJI", icon: "face.smiling.fill", index: 2)
                    }
                    .simultaneousGesture(TapGesture().onEnded {
                        SoundManager.shared.playMenuSelectSound()
                    })
                    .accessibilityLabel("Emoji Category")
                    .accessibilityHint("Play levels with emoji-based jumbles")
                    
                    NavigationLink(destination: LevelView(category: .fun)) {
                        MenuButton(title: "FUN", icon: "theatermasks.fill", index: 3)
                    }
                    .simultaneousGesture(TapGesture().onEnded {
                        SoundManager.shared.playMenuSelectSound()
                    })
                    .accessibilityLabel("Fun Category")
                    .accessibilityHint("Play fun and unique levels")
                    
                    Spacer()
                }
                .padding()
            }
        }
        .navigationViewStyle(.stack)
    }
    
    struct MenuButton: View {
        let title: String
        let icon: String
        let index: Int
        
        @State private var isAnimating = false
        
        var body: some View {
            HStack(spacing: 25) {
                Image(systemName: icon)
                    .font(.largeTitle) // Big icon
                    .rotation3DEffect(
                        .degrees(isAnimating ? 20 : -20),
                        axis: (
                            x: index % 2 == 0 ? 1 : 0, // Even index = X axis
                            y: index % 2 != 0 ? 1 : 0, // Odd index = Y axis
                            z: 0
                        )
                    )
                    .animation(
                        Animation.easeInOut(duration: 2.0)
                            .repeatForever(autoreverses: true),
                        value: isAnimating
                    )
                
                Text(title)
                    .font(.system(.title3, design: .rounded)) // Dynamic text support
                    .fontWeight(.bold)
            }
            .foregroundColor(.white)
            .frame(maxWidth: 280)
            .padding()
            .background(Capsule().fill(Color.white.opacity(0.1)))
            .overlay(Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1))
            .onAppear {
                isAnimating = true
            }
        }
    }
}
