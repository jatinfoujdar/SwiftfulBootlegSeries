import SwiftUI
import UniformTypeIdentifiers

struct LevelView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var viewModel: GameViewModel
    
    // Track positions of all letters
    @State private var letterPositions: [UUID: CGPoint] = [:]
    
    init(category: LevelCategory = .classic) {
        _viewModel = StateObject(wrappedValue: GameViewModel(category: category))
    }
    
    @State private var showWinMessage = false
    @State private var showTutorial = true

    var body: some View {
        ZStack {
            // Background
            AmbientBackground()
                .overlay(Color.black.opacity(0.3)) // Slight overlay to ensure text contrast
            
            VStack {
                // Header
                headerView
                
                Spacer()
                
                // Game Area
                ZStack(alignment: .center) {
                    
                    // Dynamic Liquid Background
                    // We need to pass the "visual" positions. 
                    // Use a binding or computed prop to modify the specific letter's pos if dragging.
                    DynamicLiquidBackground(letterPositions: computedPositions, letters: viewModel.currentLetters)
                        .frame(height: 120) // Implicit coordination
                        .foregroundColor(Color.black.opacity(0.5))
//                         .drawingGroup() // Metal optimized? Maybe not needed for simple canvas
                    
                // Letters Container
                HStack(spacing: 25) { // Increased spacing
                    ForEach(Array(viewModel.currentLetters.enumerated()), id: \.element.id) { index, letter in
                        GeometryReader { geo in
                            LetterTile(letter: letter, size: 80, fontSize: 50) // Bigger letters
                                .scaleEffect(viewModel.draggedLetter == letter ? 1.2 : 1.0)
                                .shadow(radius: viewModel.draggedLetter == letter ? 10 : 0)
                                .zIndex(viewModel.draggedLetter == letter ? 100 : 1)
                                .offset(offset(for: letter, geo: geo))
                                // Snake Jiggle Animation
                                .offset(y: viewModel.draggedLetter == letter ? 0 : snakeOffset(for: index))
                                .gesture(
                                    DragGesture(coordinateSpace: .named("GameArea"))
                                        .onChanged { value in
                                            // Update model with absolute drag location
                                            viewModel.onDragChanged(letter: letter, location: value.location)
                                            // Check for swaps
                                            checkForSwap(activeLetter: letter)
                                        }
                                        .onEnded { _ in
                                            withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                                                viewModel.onDragEnded()
                                            }
                                        }
                                )
                                .onAppear {
                                    // Initial position capture if needed, but PreferenceKey handles it
                                }
                        }
                        .frame(width: 80, height: 80) // Match new size
                        
                        // Track layout positions
                        .background(
                            GeometryReader { innerGeo in
                                Color.clear
                                    .preference(key: ViewOffsetKey.self, value: [letter.id: innerGeo.frame(in: .named("GameArea")).center])
                            }
                        )
                    }
                }
                .padding(.horizontal, 30) // More side padding
                .frame(height: 140)
            }
            .coordinateSpace(name: "GameArea")
            .onPreferenceChange(ViewOffsetKey.self) { prefs in
                self.letterPositions = prefs
            }
            .frame(height: 180)
            
            Spacer()
            
            // Tutorial Overlay
            if showTutorial && !viewModel.isGameOver {
                tutorialOverlay
            }
        }
        
        // Win Overlay
        if viewModel.isGameOver {
            winOverlay
        }
    }
    .navigationBarHidden(true)
    .onAppear {
        startSnakeAnimation()
    }
    .onChange(of: viewModel.isGameOver) { gameOver in
        if gameOver {
            // Delay showing the message
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation {
                    showWinMessage = true
                }
            }
        } else {
            showWinMessage = false
        }
    }
}

@State private var snakePhase: CGFloat = 0

func startSnakeAnimation() {
    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
        snakePhase = .pi * 2
    }
}

func snakeOffset(for index: Int) -> CGFloat {
    // Sine wave based on index + phase
    // Amplitude 5, Frequency adjusted by index
    return sin(snakePhase + Double(index) * 0.5) * 5
}

var computedPositions: [UUID: CGPoint] {
    // For background effect
    var positions = letterPositions
    if let dragged = viewModel.draggedLetter, let _ = positions[dragged.id] {
        positions[dragged.id] = viewModel.dragLocation
    }
    return positions
}

func offset(for letter: Letter, geo: GeometryProxy) -> CGSize {
    // Crucial: If this is the dragged letter, its visual position must match dragLocation.
    // The view is currently at `geo.frame(in: .named("GameArea")).center` (approximately, as updated by layout).
    // We want it to be at `viewModel.dragLocation`.
    // So Offset = Target - Current
    
    if viewModel.draggedLetter == letter {
        let currentCenter = geo.frame(in: .named("GameArea")).center
        return CGSize(
            width: viewModel.dragLocation.x - currentCenter.x,
            height: viewModel.dragLocation.y - currentCenter.y
        )
    }
    return .zero
}

func checkForSwap(activeLetter: Letter) {
    guard let draggedLoc = viewModel.draggedLetter == activeLetter ? viewModel.dragLocation : nil else { return }
    
    // Check overlap with other letters
    for other in viewModel.currentLetters where other != activeLetter {
        if let pos = letterPositions[other.id] {
             let distance = hypot(draggedLoc.x - pos.x, draggedLoc.y - pos.y)
             if distance < 40 { // Slightly generous threshold
                 withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                     viewModel.reorder(from: activeLetter, to: other)
                 }
             }
        }
    }
}
    
    // Subviews
    var headerView: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("Level \(viewModel.currentLevel.id):")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Text(viewModel.currentLevel.prompt)
                    .font(.system(size: viewModel.currentLevel.category == .emoji ? 120 : 50, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.2) // More aggressive scaling for small screens
                    .accessibilityLabel("Puzzle: \(viewModel.currentLevel.prompt)")
            }
            Spacer()
            
            HStack(spacing: 16) {
                Button(action: { 
                    SoundManager.shared.playHomeTapSound()
                    presentationMode.wrappedValue.dismiss() 
                }) {
                    Image(systemName: "house.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.white)
                    .padding(10)
                    .background(Circle().fill(Color.white.opacity(0.2)))
                }
                .accessibilityLabel("Home")
                .accessibilityHint("Return to the main menu")
                
                Button(action: { 
                    SoundManager.shared.playMenuSelectSound()
                    /* More options */ 
                }) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 20))
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Circle().fill(Color.white.opacity(0.2)))
                }
            }
        }
        .padding()
    }
    
    var tutorialOverlay: some View {
        ZStack {
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation { showTutorial = false }
                }
            
            VStack(spacing: 25) {
                Image(systemName: "hand.draw.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.blue)
                    .scaleEffect(1.2)
                
                Text(viewModel.currentLevel.category == .emoji ? "Jumble the Emojis!" : "Fix the Jumble!")
                    .font(.system(.title, design: .rounded))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("Drag the letters to their correct positions to reveal the secret word.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white.opacity(0.9))
                    .padding(.horizontal, 40)
                
                Button(action: {
                    withAnimation { showTutorial = false }
                    SoundManager.shared.playMenuSelectSound()
                }) {
                    Text("START")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 160)
                        .background(Capsule().fill(Color.blue))
                }
                .padding(.top, 10)
            }
            .padding(30)
            .background(RoundedRectangle(cornerRadius: 30).fill(Color.black.opacity(0.4)))
            .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.2), lineWidth: 1))
            .padding(20)
        }
    }
    
    var winOverlay: some View {
        ZStack {
            ConfettiView()
                .ignoresSafeArea()
                .allowsHitTesting(false)
            
            if showWinMessage {
                Color.black.opacity(0.7)
                    .ignoresSafeArea()
                    .overlay(
                        VStack(spacing: 20) {
                            Text("Correct!")
                                .font(.largeTitle)
                                .fontWeight(.heavy)
                                .foregroundColor(.green)
                            
                            Button(action: {
                                SoundManager.shared.playMenuSelectSound()
                                viewModel.nextLevel()
                            }) {
                                Text("Next Level")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(width: 200)
                                    .background(Capsule().fill(Color.blue))
                            }
                        }
                    )
                    .transition(.opacity)
            }
        }
    }
}

extension CGRect {
    var center: CGPoint {
        CGPoint(x: midX, y: midY)
    }
}


extension Color {
    init(hex: String, opacity: Double = 1.0) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        let r = Double((rgb >> 16) & 0xFF) / 255.0
        let g = Double((rgb >> 8) & 0xFF) / 255.0
        let b = Double(rgb & 0xFF) / 255.0

        self.init(.sRGB, red: r, green: g, blue: b, opacity: opacity)
    }
}
