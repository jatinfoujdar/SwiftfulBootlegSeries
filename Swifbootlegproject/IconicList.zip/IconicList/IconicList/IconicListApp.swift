//
//  IconicListApp.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//

import SwiftUI
import SwiftData

@main
struct IconicListApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
        .modelContainer(for: ReminderList.self)
    }
}
