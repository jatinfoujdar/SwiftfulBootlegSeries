//
//  ReminderListView.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//

import SwiftUI
import SwiftData

struct ReminderListView: View {
    @Environment(\.modelContext) var modelContext
    @Bindable var reminderList: ReminderList
    
    private let colorPalette: [Color] = [.blue, .green, .mint, .teal, .cyan, .indigo, .purple, .pink, .red, .orange, .yellow, .brown, .gray]
    private var accentColor: Color {
        let key = (reminderList.name + reminderList.iconName)
        let hashValue = abs(key.hashValue)
        return colorPalette[hashValue % colorPalette.count]
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(accentColor.gradient)
                        .frame(width: 40, height: 40)
                    Image(systemName: reminderList.iconName)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(reminderList.name)
                        .font(.system(.title2, design: .rounded, weight: .bold))
                    Text("\(reminderList.reminder.count) items")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal)
            
            List {
                ForEach(reminderList.reminder) { reminders in
                    ReminderRowView(reminder: reminders)
                }
                .onDelete(perform: delete)
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Button {
                    reminderList.reminder.append(Reminder(name: ""))
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: "plus.circle.fill")
                        Text("New Reminder")
                    }
                    .font(.system(.body, design: .rounded))
                    .bold()
                }
                Spacer()
            }
        }
        .tint(accentColor)
        .background(
            LinearGradient(colors: [accentColor.opacity(0.12), .clear], startPoint: .top, endPoint: .bottom)
        )
    }
    
    func delete(_ indexSet: IndexSet) {
        for index in indexSet {
            reminderList.reminder.remove(at: index)
        }
        try! modelContext.save()
    }
}

#Preview {
    do {
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: ReminderList.self, configurations: config)
        let example = ReminderList(name: "Scheduled", iconName: "calendar", reminder: [Reminder(name: "Lunch with Janet")])
        
        return ReminderListView(reminderList: example)
            .modelContainer(container)
    } catch {
        fatalError("Failed to create model container.")
    }
}
