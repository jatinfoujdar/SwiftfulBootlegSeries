//
//  ReminderRowView.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//


import SwiftUI
import SwiftData

struct ReminderRowView: View {
    @Environment(\.modelContext) var modelContext
    @Bindable var reminder: Reminder
    
    var body: some View {
        HStack(spacing: 12) {
            Button {
                withAnimation(.easeInOut(duration: 0.15)) {
                    reminder.isCompleted.toggle()
                }
            } label: {
                Image(systemName: reminder.isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 20, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)
//                    .foregroundStyle(reminder.isCompleted ? .tint : .tertiary)
            }
            .buttonStyle(.plain)
            
            TextField(reminder.name, text: $reminder.name)
                .font(.body)
                .foregroundStyle(reminder.isCompleted ? .secondary : .primary)
                .strikethrough(reminder.isCompleted, color: .secondary)
                .opacity(reminder.isCompleted ? 0.7 : 1)
        }
    }
    
   
}

#Preview {
    do {
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: Reminder.self, configurations: config)
        let example = Reminder(name: "Reminder Example", isCompleted: false)
        
        return ReminderRowView(reminder: example)
            .modelContainer(container)
    } catch {
        fatalError("Failed to create model container")
    }
}
