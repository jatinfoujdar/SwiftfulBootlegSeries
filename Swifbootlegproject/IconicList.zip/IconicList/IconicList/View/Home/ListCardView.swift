//
//  ListCardView.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//

import SwiftUI
import SwiftData

struct ListCardView: View {
    @Bindable var reminderList: ReminderList
    @State private var linkIsActive = false
    
    private let colorPalette: [Color] = [.blue, .green, .mint, .teal, .cyan, .indigo, .purple, .pink, .red, .orange, .yellow, .brown, .gray]
    
    private var accentColor: Color {
        let key = (reminderList.name + reminderList.iconName)
        let hashValue = abs(key.hashValue)
        return colorPalette[hashValue % colorPalette.count]
    }
    
    var body: some View {
        Button {
            linkIsActive = true
        } label: {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .center) {
                    listIcon
                    Spacer()
                    Text("\(reminderList.reminder.count)")
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .foregroundStyle(.primary)
                }
                Text(reminderList.name)
                    .font(.system(.headline, design: .rounded, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(12)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(LinearGradient(colors: [accentColor.opacity(0.22), accentColor.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(.ultraThinMaterial)
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(accentColor.opacity(0.35), lineWidth: 1)
            )
            .shadow(color: accentColor.opacity(0.12), radius: 10, x: 0, y: 6)
        }
        .overlay(
            NavigationLink(isActive: $linkIsActive,
                           destination: { ReminderListView(reminderList: reminderList) },
                           label: { EmptyView() }
                          ).opacity(0)
        ).buttonStyle(.plain)
    }
    
    var listIcon: some View {
        ZStack {
            Circle()
                .fill(accentColor.gradient)
                .frame(width: 34, height: 34)
            Image(systemName: reminderList.iconName)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
        }
    }
}

#Preview {
    do {
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: ReminderList.self, configurations: config)
        let example = ReminderList(name: "Today", iconName: "sun.max.fill", reminder: [Reminder(name: "Walk the dog")])
        
        return ListCardView(reminderList: example)
            .modelContainer(container)
    } catch {
        fatalError("Failed to create a model container.")
    }
}
