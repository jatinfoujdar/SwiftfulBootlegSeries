//
//  CreateSectionView.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//

import SwiftUI
import SwiftData

struct CreateSectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Bindable var reminderList: ReminderList
    
    
    @State private var selectedColor: Color = .blue
    private let colorPalette: [Color] = [.blue, .green, .mint, .teal, .cyan, .indigo, .purple, .pink, .red, .orange, .yellow, .brown, .gray]
    
    var body: some View {
        Form {
            
            Section {
                HStack {
                    ZStack {
                        Circle()
                            .fill(selectedColor.gradient)
                            .frame(width: 56, height: 56)
                        Image(systemName: reminderList.iconName.isEmpty ? "circle" : reminderList.iconName)
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    .overlay(
                        Circle()
                            .strokeBorder(selectedColor.opacity(0.35), lineWidth: 1)
                    )
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(reminderList.name.isEmpty ? "New Segment" : reminderList.name)
                            .font(.headline)
                        Text("Preview")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .listRowBackground(Color.clear)
            }
            
            Section("Color") {
                // Compact, colorful palette
                LazyVGrid(columns: Array(repeating: .init(.flexible(), spacing: 12), count: 6), spacing: 12) {
                    ForEach(colorPalette.indices, id: \.self) { index in
                        let color = colorPalette[index]
                        Button {
                            selectedColor = color
                        } label: {
                            ZStack {
                                Circle()
                                    .fill(color.gradient)
                                    .frame(width: 28, height: 28)
                                if color == selectedColor {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(.white)
                                        .shadow(radius: 2)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(Text("Select color"))
                    }
                }
                .padding(.vertical, 4)
            }
            
            Section("Name") {
                TextField("Enter name", text: $reminderList.name)
                    .textInputAutocapitalization(.words)
                    .submitLabel(.done)
            }
            
            Section("Icon") {
                Picker("Icon", selection: $reminderList.iconName) {
                   
                    Label("Home", systemImage: "house").tag("house" as String)
                    Label("Heart", systemImage: "heart").tag("heart" as String)
                    Label("Calendar", systemImage: "calendar").tag("calendar" as String)
                    Label("Flag", systemImage: "flag.fill").tag("flag.fill" as String)
                    Label("Sun", systemImage: "sun.max.fill").tag("sun.max.fill" as String)
                    Label("Graduation", systemImage: "graduationcap").tag("graduationcap" as String)
                    Label("Important", systemImage: "exclamationmark.3").tag("exclamationmark.3" as String)
                }
                .pickerStyle(.automatic)
            }
        }
        .formStyle(.grouped)
        .scrollContentBackground(.hidden)
        .background(
            LinearGradient(colors: [selectedColor.opacity(0.18), .clear], startPoint: .top, endPoint: .bottom)
        )
        .navigationTitle("Add Segment")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Done") { dismiss() }
                    .disabled(reminderList.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .tint(selectedColor)
        .animation(.easeInOut(duration: 0.2), value: selectedColor)
    }
}

#Preview {
    CreateSectionView(reminderList: ReminderList())
}
