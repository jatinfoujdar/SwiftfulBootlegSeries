//
//  ReminderListRowView.swift
//  IconicList
//
//  Created by jatin foujdar on 20/10/25.
//

import SwiftUI
import SwiftData

struct ReminderListRowView: View {
    @Bindable var reminderList: ReminderList
    
    private let colorPalette: [Color] = [.blue, .green, .mint, .teal, .cyan, .indigo, .purple, .pink, .red, .orange, .yellow, .brown, .gray]
    private var accentColor: Color {
        let key = (reminderList.name + reminderList.iconName)
        let hashValue = abs(key.hashValue)
        return colorPalette[hashValue % colorPalette.count]
    }
    
    var body: some View {
        HStack(spacing: 12) {
            listIcon
            VStack(alignment: .leading, spacing: 2) {
                Text(reminderList.name)
                    .font(.body.weight(.semibold))
                Text("\(reminderList.reminder.count) items")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.tertiary)
        }
    }
    
    var listIcon: some View {
        ZStack {
            Circle()
                .fill(accentColor.gradient)
                .frame(width: 28, height: 28)
            Image(systemName: reminderList.iconName)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.white)
        }
    }
}

#Preview {
    do {
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: ReminderList.self, configurations: config)
        let example = ReminderList(name: "App Team", iconName: "iphone", reminder: [Reminder(name: "Talk to Same"), Reminder(name: "Collect bounty")])
        
        return ReminderListRowView(reminderList: example)
            .modelContainer(container)
    } catch {
        fatalError("Failed to create model container")
    }
}
