import Foundation

let SCHEMA_VERSION: UInt64 = 0
let PREF_USER_ID: String = "userId"
let PREF_USER_NAME: String = "userName"
let PREF_USER_EMAIL: String = "userEmail"
let PREF_USER_TYPE: String = "userType"

let SPRAED_SHEET_HEAD_REST = "mimeType = 'application/vnd.google-apps.spreadsheet'"
let SPREAD_SHEET_MIMETYPE_REST = "application/vnd.google-apps.spreadsheet"
