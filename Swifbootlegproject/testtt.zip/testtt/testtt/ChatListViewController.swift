//
//  ViewController.swift
//  testtt
//"title": "Sample Item 1",
//"description": "This is a sample description for item number 1. It contains general information about the content and purpose of this particular entry in the JSON list.",
//"image": {
//  "url": "https://picsum.photos/id/1/600/400",
//  "type": "image"
//}
//  Created by jatin foujdar on 24/12/25.
//
//import SwiftUI
import UIKit

   


struct Chat :  Decodable{
    let title : String?
    let description: String?
    let image: ImageData?
}

struct ImageData: Decodable {
    let url: String?
    let type: String?

    enum CodingKeys: String, CodingKey {
        case url, type
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        url = try container.decodeIfPresent(String.self, forKey: .url)

        if let stringType = try? container.decode(String.self, forKey: .type) {
            type = stringType
        } else if let intType = try? container.decode(Int.self, forKey: .type) {
            type = String(intType)
        } else {
            type = nil
        }
    }
}


class ChatListViewController : UIViewController , UITableViewDataSource{
    
    private let tableView = UITableView()
    private var chats: [Chat] = []
    
    override func viewDidLoad(){
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setupTableView()
        loadJSON()
    }
    
    func setupTableView(){
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(ChatTableViewCell.self, forCellReuseIdentifier: ChatTableViewCell.identifier)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        chats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let chat = chats[indexPath.row]
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ChatTableViewCell.identifier, for: indexPath) as? ChatTableViewCell else {
            return UITableViewCell()
        }
        cell.configure(with: chat)
        return cell
    }
 
    private func loadJSON() {
            guard let url = Bundle.main.url(forResource: "data", withExtension: "json") else {
                print("❌ data.json not found")
                return
            }

            do {
                let data = try Data(contentsOf: url)
                chats = try JSONDecoder().decode([Chat].self, from: data)
                tableView.reloadData()
            } catch {
                print("❌ Error loading JSON:", error)
            }
        }
}



class ChatTableViewCell: UITableViewCell {

    static let identifier = "ChatTableViewCell"

    let chatImageView = UIImageView()
    let titleLabel = UILabel()
    let descriptionLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {

        chatImageView.translatesAutoresizingMaskIntoConstraints = false
        chatImageView.contentMode = .scaleAspectFill
        chatImageView.clipsToBounds = true
        chatImageView.layer.cornerRadius = 8
        chatImageView.backgroundColor = .systemGray5

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = .boldSystemFont(ofSize: 16)

        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.font = .systemFont(ofSize: 14)
        descriptionLabel.numberOfLines = 2
        descriptionLabel.textColor = .darkGray

        contentView.addSubview(chatImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(descriptionLabel)

        NSLayoutConstraint.activate([
            chatImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            chatImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            chatImageView.widthAnchor.constraint(equalToConstant: 60),
            chatImageView.heightAnchor.constraint(equalToConstant: 60),

            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            titleLabel.leadingAnchor.constraint(equalTo: chatImageView.trailingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),

            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            descriptionLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            descriptionLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            descriptionLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -12)
        ])
    }

    func configure(with chat: Chat) {
        titleLabel.text = chat.title ?? "No Title"
        descriptionLabel.text = chat.description ?? "No Description"
        chatImageView.loadImage(from: chat.image?.url)
    }
}

extension ChatListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 84
    }
}

extension UIImageView {
    func loadImage(from urlString: String?) {
        guard let urlString = urlString, let url = URL(string: urlString) else {
            self.image = nil
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                print("Error loading image: \(error)")
                return
            }
            
            guard let data = data, let image = UIImage(data: data) else { return }
            
            DispatchQueue.main.async {
                self?.image = image
            }
        }.resume()
    }
}
