//
//  quest.swift
//  testtt
//
//  Created by jatin foujdar on 24/12/25.
//

//i have to mkae list of whatapp chat type ui with uikit programmatic ui parse the data from json file
