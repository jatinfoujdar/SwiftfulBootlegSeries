//
//  BadgeFlagView.swift
//  OhMyFlag
//
//  Created by Frank Chu on 4/10/22.
//

import SwiftUI
import CoreData

struct BadgeFlagView: View {
//    @FetchRequest(sortDescriptors: []) var flagsBadgeView: FetchedResults<FlagEntities>
//    @Environment(\.managedObjectContext) var mocInBadgeFlagView
    let flag: FlagEntities
    var body: some View {
        
        VStack(spacing: 8) {
            Text(flag.emojiFlag)
                .frame(height: 96)
                .font(.system(size: 96))
                .padding(.top, 16)
                .padding(.horizontal, 16)

            VStack(spacing: 4) {
                Text(flag.nameFlag)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)

                Text(flag.shortIntro)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
            .background(.cardBackground, in: RoundedRectangle(cornerRadius: 12))
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(.quaternary, lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(flag.nameFlag) flag: \(flag.shortIntro)")
    }
    
}

//struct BadgeFlagView_Previews: PreviewProvider {
//    static var previews: some View {
//        BadgeFlagView()
//    }
//}
