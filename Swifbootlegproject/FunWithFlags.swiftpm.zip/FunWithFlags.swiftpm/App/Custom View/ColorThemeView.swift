//
//  ColorThemeView.swift
//  OhMyFlag
//
//  Created by Frank Chu on 4/10/22.
//

import Foundation
import SwiftUI

extension ShapeStyle where Self == Color {
    static var darkBackground: Color {
        // Force dark background for consistent dark theme
        Color.black
    }
    
    static var lightBackground: Color {
        // Dark mode secondary background
        Color(.systemGray6)
    }
    
    // Apple's modern semantic colors optimized for dark mode
    static var cardBackground: Color {
        Color(.systemGray5)
    }
    
    static var accentBackground: Color {
        Color.accentColor.opacity(0.2)
    }
}

