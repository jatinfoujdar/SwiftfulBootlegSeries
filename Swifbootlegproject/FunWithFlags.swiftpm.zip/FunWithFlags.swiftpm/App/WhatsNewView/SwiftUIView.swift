//
//  SwiftUIView.swift
//  
//
//  Created by Frank Chu on 5/12/22.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        ScrollView {
            
        }
        .background(.darkBackground)

    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
