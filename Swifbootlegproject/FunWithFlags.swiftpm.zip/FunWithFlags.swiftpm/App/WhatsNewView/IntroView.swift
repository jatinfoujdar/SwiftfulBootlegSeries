//
//  IntroView.swift
//  OhMyFlag
//
//  Created by Frank Chu on 4/11/22.
//

import SwiftUI

struct IntroView: View {
    var body: some View {
//        (alignment: .leading)
        GeometryReader { geometry in
            
            VStack(spacing: 32) {
                Spacer()
                
                VStack(spacing: 16) {
                    Image(systemName: "flag.2.crossed")
                        .font(.system(size: 60))
                        .foregroundColor(.accentColor)
                    
                    Text("Welcome to Oh My Flag!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                }
                
                VStack(spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.accentColor)
                        Text("Add new flags to your collection")
                            .font(.headline)
                    }
                    
                    HStack(spacing: 12) {
                        Image(systemName: "shuffle")
                            .foregroundColor(.accentColor)
                        Text("Discover random flags in drawing mode")
                            .font(.headline)
                    }
                    
                    HStack(spacing: 12) {
                        Image(systemName: "questionmark.circle")
                            .foregroundColor(.accentColor)
                        Text("Test your knowledge in quiz mode")
                            .font(.headline)
                    }
                }
                .padding(.horizontal, 32)
                
                Text("Enjoy the app in landscape mode for the best experience")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.horizontal)
        }
        .background(.darkBackground)
        .preferredColorScheme(.dark)
    }
}

struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
