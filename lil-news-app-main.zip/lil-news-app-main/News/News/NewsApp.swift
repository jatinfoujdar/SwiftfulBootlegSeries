//
//  NewsApp.swift
//  News
//
//  Created by Jordan Singer on 2/10/21.
//

import SwiftUI

@main
struct NewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
