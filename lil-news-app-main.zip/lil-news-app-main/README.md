# lil news app
Using [lil news api](https://lil.software/api)

![News](https://user-images.githubusercontent.com/110813/107532668-20834780-6b8c-11eb-9dcd-d53c4739e37f.png)
